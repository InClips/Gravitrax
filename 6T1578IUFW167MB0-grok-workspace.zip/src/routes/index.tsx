import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useState } from "react";

const App = lazy(() => import("@/components/ecliptique/app"));

export const Route = createFileRoute("/")({
  ssr: false,
  component: Home,
});

function Home() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  return (
    <main className="h-dvh w-full bg-bg text-fg">
      {ready ? (
        <Suspense fallback={<Boot />}>
          <App />
        </Suspense>
      ) : (
        <Boot />
      )}
    </main>
  );
}

function Boot() {
  return (
    <div className="flex h-dvh flex-col items-center justify-center gap-3">
      <p className="font-display text-4xl text-fg">Écliptique</p>
      <p className="text-sm text-muted">Le circuit se déplie…</p>
    </div>
  );
}
