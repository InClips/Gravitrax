import { OrbitControls } from "@react-three/drei";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { playCue, unlockAudio } from "@/game/audio";
import { CATALOG, CHANNEL_COLORS, type Profile } from "@/game/catalog";
import { GRID, HEX_R, LEVEL_H, hexToXZ, worldToAxial } from "@/game/hex";
import { focusOf } from "@/game/layouts";
import {
  activeMarbles,
  createSim,
  resetMarbles,
  sampleRide,
  startsDone,
  stepSim,
  syncPieces,
  visualRides,
  type Placed,
  type Sim,
} from "@/game/sim";
import { useEditor } from "@/game/store";

const GOLD = "#e7b15a";
const TEAL = "#3ecfb8";
const INK = "#121018";

function Sky() {
  const mat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        side: THREE.BackSide,
        uniforms: { uTime: { value: 0 } },
        vertexShader: `
          varying vec3 vPos;
          void main() {
            vPos = position;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          varying vec3 vPos;
          uniform float uTime;
          void main() {
            vec3 n = normalize(vPos);
            float h = n.y * 0.5 + 0.5;
            vec3 deep = vec3(0.03, 0.025, 0.055);
            vec3 tide = vec3(0.04, 0.16, 0.15);
            vec3 gold = vec3(0.28, 0.14, 0.05);
            vec3 col = mix(deep, tide, smoothstep(0.05, 0.85, h));
            float w = sin(n.x * 7.0 + uTime * 0.12) * sin(n.z * 5.0 - uTime * 0.08);
            col += gold * smoothstep(0.35, 1.0, w) * 0.28 * h;
            gl_FragColor = vec4(col, 1.0);
          }
        `,
      }),
    [],
  );
  useFrame((_, d) => {
    mat.uniforms.uTime!.value += Math.min(d, 0.1);
  });
  useEffect(() => () => mat.dispose(), [mat]);
  return (
    <mesh frustumCulled={false}>
      <sphereGeometry args={[48, 28, 20]} />
      <primitive object={mat} attach="material" />
    </mesh>
  );
}

function Stars() {
  const geom = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const pos = new Float32Array(420 * 3);
    for (let i = 0; i < 420; i++) {
      const y = 2 + Math.random() * 22;
      const a = Math.random() * Math.PI * 2;
      const rad = 6 + Math.random() * 28;
      pos[i * 3] = Math.cos(a) * rad;
      pos[i * 3 + 1] = y;
      pos[i * 3 + 2] = Math.sin(a) * rad;
    }
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    return g;
  }, []);
  useEffect(() => () => geom.dispose(), [geom]);
  return (
    <points geometry={geom}>
      <pointsMaterial color="#f4efe6" size={0.045} sizeAttenuation />
    </points>
  );
}

function Pads() {
  const ref = useRef<THREE.InstancedMesh>(null);
  useEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    const dummy = new THREE.Object3D();
    GRID.forEach(([q, r], i) => {
      const [x, z] = hexToXZ(q, r);
      dummy.position.set(x, 0.02, z);
      dummy.rotation.set(0, Math.PI / 6, 0);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
  }, []);
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, GRID.length]} frustumCulled={false} raycast={() => {}}>
      <cylinderGeometry args={[HEX_R * 0.98, HEX_R * 0.98, 0.035, 6]} />
      <meshStandardMaterial color="#14121c" roughness={0.92} metalness={0.18} />
    </instancedMesh>
  );
}

function RailTube({ points, profile, accent }: { points: THREE.Vector3[]; profile: Profile; accent: string }) {
  const geom = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3(points, false, "centripetal", 0.4);
    const radius = profile === "tunnel" ? 0.095 : profile === "dip" ? 0.05 : 0.04;
    return new THREE.TubeGeometry(curve, 32, radius, 5, false);
  }, [points, profile]);
  useEffect(() => () => geom.dispose(), [geom]);
  const color =
    profile === "loop" || profile === "spiral"
      ? GOLD
      : profile === "tunnel"
        ? "#9aa4b5"
        : profile === "dip" || accent === "teal"
          ? "#b7efe6"
          : "#f6efe2";
  return (
    <mesh geometry={geom}>
      <meshStandardMaterial
        color={color}
        emissive={accent === "teal" ? TEAL : GOLD}
        emissiveIntensity={profile === "tunnel" ? 0.04 : 0.22}
        roughness={0.28}
        metalness={0.42}
      />
    </mesh>
  );
}

function Arrow({ rot }: { rot: number }) {
  const ang = rot * (Math.PI / 3);
  return (
    <group rotation={[0, -ang, 0]}>
      <mesh position={[0.5, 0.16, 0]}>
        <boxGeometry args={[0.2, 0.028, 0.055]} />
        <meshStandardMaterial color={GOLD} emissive={GOLD} emissiveIntensity={0.35} metalness={0.4} roughness={0.35} />
      </mesh>
    </group>
  );
}

function Gadget({ piece }: { piece: Placed }) {
  const ang = piece.rot * (Math.PI / 3);
  const ch = CHANNEL_COLORS[piece.channel ?? 0] ?? GOLD;
  const id = piece.type;
  return (
    <group rotation={[0, -ang, 0]}>
      {(id === "canon" || id === "aimant" || id === "tremplin") && (
        <mesh position={[0.16, 0.28, 0]} rotation={[0, 0, -Math.PI / 2]}>
          <cylinderGeometry args={[id === "aimant" ? 0.12 : 0.09, 0.14, 0.52, 10]} />
          <meshStandardMaterial color={id === "aimant" ? "#2a2420" : INK} metalness={0.72} roughness={0.28} emissive={id === "aimant" ? "#5a2a28" : "#000"} emissiveIntensity={0.4} />
        </mesh>
      )}
      {id === "aimant" && (
        <mesh position={[0.34, 0.28, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[0.16, 0.028, 8, 16]} />
          <meshStandardMaterial color="#e25b6a" emissive="#e25b6a" emissiveIntensity={0.5} />
        </mesh>
      )}
      {(id === "volcan" || id === "fontaine") && (
        <mesh position={[0, 0.22, 0]}>
          <coneGeometry args={[0.28, 0.38, 8]} />
          <meshStandardMaterial color={id === "fontaine" ? TEAL : "#c9846a"} emissive={id === "fontaine" ? TEAL : "#e25b6a"} emissiveIntensity={0.35} roughness={0.45} />
        </mesh>
      )}
      {id === "catapulte" && (
        <mesh position={[0.12, 0.28, 0]} rotation={[0, 0, -0.9]}>
          <boxGeometry args={[0.46, 0.05, 0.08]} />
          <meshStandardMaterial color={GOLD} metalness={0.55} roughness={0.35} />
        </mesh>
      )}
      {id === "marteau" && (
        <mesh position={[0.05, 0.42, 0.12]} rotation={[0.4, 0, 0]}>
          <boxGeometry args={[0.1, 0.34, 0.1]} />
          <meshStandardMaterial color="#d9d2c5" metalness={0.5} roughness={0.3} />
        </mesh>
      )}
      {(id === "trampoline" || id === "lune" || id === "portail" || id === "vortex") && (
        <mesh position={[0, id === "trampoline" ? 0.16 : 0.32, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[id === "trampoline" ? 0.22 : 0.3, 0.03, 8, 20]} />
          <meshStandardMaterial color={id === "portail" ? ch : TEAL} emissive={id === "portail" ? ch : TEAL} emissiveIntensity={0.7} />
        </mesh>
      )}
      {(id === "chute" || id === "chute2" || id === "trou") && (
        <mesh position={[0, 0.08, 0]}>
          <cylinderGeometry args={[0.2, 0.12, id === "trou" ? 0.28 : 0.16, 12]} />
          <meshStandardMaterial color="#07060c" roughness={0.4} metalness={0.2} emissive={id === "trou" ? "#e25b6a" : "#000"} emissiveIntensity={id === "trou" ? 0.25 : 0} />
        </mesh>
      )}
      {(id === "receptacle" || id === "entonnoir" || id === "panier" || id === "arrivee" || id === "carillon") && (
        <mesh position={[0, 0.18, 0]}>
          <cylinderGeometry args={[id === "entonnoir" || id === "panier" ? 0.34 : 0.26, 0.12, 0.16, 10]} />
          <meshStandardMaterial color="#efe6d4" emissive={id === "carillon" ? GOLD : TEAL} emissiveIntensity={0.18} transparent opacity={0.85} roughness={0.25} />
        </mesh>
      )}
      {id === "elevateur" && (
        <mesh position={[0, 0.7, 0]}>
          <cylinderGeometry args={[0.05, 0.05, 1.3, 8]} />
          <meshStandardMaterial color={TEAL} emissive={TEAL} emissiveIntensity={0.45} />
        </mesh>
      )}
      {(id === "butee" || id === "pilier" || id === "depart") && (
        <mesh position={[0, 0.28, 0]}>
          <cylinderGeometry args={[id === "depart" ? 0.08 : 0.1, 0.12, id === "pilier" ? 0.4 : 0.36, 8]} />
          <meshStandardMaterial color={id === "depart" ? GOLD : "#d7ece6"} emissive={id === "depart" ? GOLD : TEAL} emissiveIntensity={0.25} />
        </mesh>
      )}
      {id === "prisme" && (
        <mesh position={[0, 0.32, 0]} rotation={[0.4, 0.6, 0]}>
          <octahedronGeometry args={[0.2, 0]} />
          <meshStandardMaterial color="#f4efe6" emissive="#e25b6a" emissiveIntensity={0.35} metalness={0.3} roughness={0.15} />
        </mesh>
      )}
      {id === "miroir" && (
        <mesh position={[0.12, 0.28, 0]}>
          <boxGeometry args={[0.06, 0.36, 0.28]} />
          <meshStandardMaterial color="#f4efe6" emissive={TEAL} emissiveIntensity={0.2} metalness={0.85} roughness={0.08} />
        </mesh>
      )}
      {id === "nebuleuse" && (
        <mesh position={[0, 0.3, 0]}>
          <icosahedronGeometry args={[0.16, 0]} />
          <meshStandardMaterial color={TEAL} emissive={TEAL} emissiveIntensity={0.8} />
        </mesh>
      )}
      {id === "eclipse" && (
        <mesh position={[0, 0.3, 0]}>
          <sphereGeometry args={[0.14, 16, 16]} />
          <meshStandardMaterial color="#07060c" emissive={GOLD} emissiveIntensity={0.15} />
        </mesh>
      )}
      {(id === "tyrolienne") && (
        <mesh position={[1.3, 0.22, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.012, 0.012, 2.4, 5]} />
          <meshStandardMaterial color={GOLD} emissive={GOLD} emissiveIntensity={0.4} />
        </mesh>
      )}
      {id === "vanne" && (
        <mesh position={[0, 0.28, 0]}>
          <boxGeometry args={[0.08, 0.32, 0.36]} />
          <meshStandardMaterial color="#d7cec2" metalness={0.45} roughness={0.35} />
        </mesh>
      )}
      {id === "bascule" && (
        <mesh position={[0, 0.2, 0]} rotation={[0, 0, 0.25]}>
          <boxGeometry args={[0.7, 0.04, 0.16]} />
          <meshStandardMaterial color={GOLD} metalness={0.4} roughness={0.4} />
        </mesh>
      )}
    </group>
  );
}

function PieceView({ piece, selected }: { piece: Placed; selected: boolean }) {
  const def = CATALOG[piece.type];
  const [x, z] = hexToXZ(piece.q, piece.r);
  const y = piece.level * LEVEL_H;
  const tubes = useMemo(() => {
    if (!def) return [];
    return visualRides(piece, def).map((ride) => {
      const pts: THREE.Vector3[] = [];
      const n = ride.profile === "loop" || ride.profile === "spiral" ? 36 : 16;
      for (let i = 0; i <= n; i++) {
        const p = sampleRide(ride, i / n);
        pts.push(new THREE.Vector3(p.x, p.y, p.z));
      }
      return { pts, profile: ride.profile };
    });
  }, [def, piece]);
  if (!def) return null;
  return (
    <group>
      <mesh position={[x, y + 0.08, z]} rotation={[0, Math.PI / 6, 0]} castShadow={false}>
        <cylinderGeometry args={[HEX_R * 0.9, HEX_R * 0.9, 0.12, 6]} />
        <meshStandardMaterial
          color={selected ? "#f7f3ea" : "#d7ebe4"}
          emissive={def.accent === "coral" ? "#e25b6a" : def.accent === "teal" ? TEAL : "#12302c"}
          emissiveIntensity={selected ? 0.18 : 0.08}
          roughness={0.22}
          metalness={0.12}
          transparent
          opacity={0.92}
        />
      </mesh>
      {piece.level > 0 && (
        <mesh position={[x, y * 0.5 + 0.02, z]}>
          <cylinderGeometry args={[0.035, 0.035, Math.max(0.08, y), 6]} />
          <meshStandardMaterial color="#123830" emissive={TEAL} emissiveIntensity={0.55} />
        </mesh>
      )}
      <group position={[x, y, z]}>
        <Arrow rot={piece.rot} />
        <Gadget piece={piece} />
      </group>
      {tubes.map((tube, i) => (
        <RailTube key={i} points={tube.pts} profile={tube.profile} accent={def.accent} />
      ))}
      {selected && (
        <mesh position={[x, y + 0.17, z]} rotation={[-Math.PI / 2, 0, Math.PI / 6]} raycast={() => {}}>
          <ringGeometry args={[HEX_R * 0.78, HEX_R * 0.92, 6]} />
          <meshBasicMaterial color={GOLD} />
        </mesh>
      )}
    </group>
  );
}

function Ghost({ q, r }: { q: number; r: number }) {
  const tool = useEditor((s) => s.tool);
  const level = useEditor((s) => s.brushLevel);
  const rot = useEditor((s) => s.brushRot);
  const mode = useEditor((s) => s.mode);
  const [x, z] = hexToXZ(q, r);
  const y = level * LEVEL_H;
  if (mode === "erase") {
    return (
      <mesh position={[x, y + 0.18, z]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[HEX_R * 0.55, HEX_R * 0.78, 6]} />
        <meshBasicMaterial color="#e25b6a" transparent opacity={0.85} />
      </mesh>
    );
  }
  const def = CATALOG[tool];
  if (!def) return null;
  return (
    <group position={[x, y, z]}>
      <mesh position={[0, 0.1, 0]} rotation={[0, Math.PI / 6, 0]}>
        <cylinderGeometry args={[HEX_R * 0.9, HEX_R * 0.9, 0.08, 6]} />
        <meshStandardMaterial color="#f4efe6" transparent opacity={0.28} emissive={TEAL} emissiveIntensity={0.2} />
      </mesh>
      <Arrow rot={rot} />
    </group>
  );
}

function Marbles({ simRef }: { simRef: React.RefObject<Sim | null> }) {
  const core = useRef<THREE.InstancedMesh>(null);
  const halo = useRef<THREE.InstancedMesh>(null);
  const sparks = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const color = useMemo(() => new THREE.Color(), []);

  useFrame(() => {
    const sim = simRef.current;
    const mesh = core.current;
    const glow = halo.current;
    const fx = sparks.current;
    if (!sim || !mesh || !glow || !fx) return;
    let i = 0;
    for (const m of sim.marbles) {
      if (m.hide || m.mode === "gone") continue;
      if (i >= 24) break;
      dummy.position.set(m.pos.x, m.pos.y, m.pos.z);
      dummy.scale.setScalar(1);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
      color.set(m.color);
      mesh.setColorAt(i, color);
      const s = m.trail ? 2.1 : 1.65;
      dummy.scale.setScalar(s);
      dummy.updateMatrix();
      glow.setMatrixAt(i, dummy.matrix);
      glow.setColorAt(i, color);
      i++;
    }
    mesh.count = i;
    glow.count = i;
    mesh.instanceMatrix.needsUpdate = true;
    glow.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    if (glow.instanceColor) glow.instanceColor.needsUpdate = true;

    let k = 0;
    for (const f of sim.fx) {
      if (k >= 48) break;
      const sc = Math.max(0.01, (f.life / f.max) * 0.12);
      dummy.position.set(f.x, f.y, f.z);
      dummy.scale.setScalar(sc / 0.07);
      dummy.updateMatrix();
      fx.setMatrixAt(k, dummy.matrix);
      color.set(f.color);
      fx.setColorAt(k, color);
      k++;
    }
    fx.count = k;
    fx.instanceMatrix.needsUpdate = true;
    if (fx.instanceColor) fx.instanceColor.needsUpdate = true;
  });

  return (
    <>
      <instancedMesh ref={core} args={[undefined, undefined, 24]} frustumCulled={false}>
        <sphereGeometry args={[0.12, 18, 18]} />
        <meshStandardMaterial roughness={0.18} metalness={0.62} />
      </instancedMesh>
      <instancedMesh ref={halo} args={[undefined, undefined, 24]} frustumCulled={false}>
        <sphereGeometry args={[0.12, 10, 10]} />
        <meshBasicMaterial transparent opacity={0.22} depthWrite={false} blending={THREE.AdditiveBlending} />
      </instancedMesh>
      <instancedMesh ref={sparks} args={[undefined, undefined, 48]} frustumCulled={false}>
        <sphereGeometry args={[0.07, 6, 6]} />
        <meshBasicMaterial transparent opacity={0.9} depthWrite={false} blending={THREE.AdditiveBlending} />
      </instancedMesh>
    </>
  );
}

function Picker() {
  const { camera, gl } = useThree();
  useEffect(() => {
    const ray = new THREE.Raycaster();
    const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -0.04);
    const ndc = new THREE.Vector2();
    const hit = new THREE.Vector3();
    let down: { x: number; y: number } | null = null;
    const el = gl.domElement;

    const pointOf = (e: PointerEvent) => {
      const rect = el.getBoundingClientRect();
      ndc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      ndc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      ray.setFromCamera(ndc, camera);
      return ray.ray.intersectPlane(plane, hit);
    };

    const move = (e: PointerEvent) => {
      const p = pointOf(e);
      if (!p) return;
      useEditor.getState().setHover(worldToAxial(p.x, p.z));
    };
    const dn = (e: PointerEvent) => {
      down = { x: e.clientX, y: e.clientY };
    };
    const up = (e: PointerEvent) => {
      if (!down) return;
      const dx = e.clientX - down.x;
      const dy = e.clientY - down.y;
      down = null;
      if (dx * dx + dy * dy > 81) return;
      const p = pointOf(e);
      if (!p) return;
      unlockAudio();
      const cell = worldToAxial(p.x, p.z);
      useEditor.getState().placeAt(cell.q, cell.r);
    };
    const leave = () => useEditor.getState().setHover(null);

    el.addEventListener("pointermove", move);
    el.addEventListener("pointerdown", dn);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointerleave", leave);
    return () => {
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerdown", dn);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointerleave", leave);
    };
  }, [camera, gl]);
  return null;
}

function World({ autoRotate }: { autoRotate: boolean }) {
  const pieces = useEditor((s) => s.pieces);
  const selectedId = useEditor((s) => s.selectedId);
  const hover = useEditor((s) => s.hover);
  const viewToken = useEditor((s) => s.viewToken);
  const runToken = useEditor((s) => s.runToken);
  const brushLevel = useEditor((s) => s.brushLevel);
  const simRef = useRef<Sim | null>(null);
  if (!simRef.current) simRef.current = createSim(pieces);
  const sim = simRef.current;
  const acc = useRef(0);
  const hudAcc = useRef(0);
  const light = useRef<THREE.PointLight>(null);
  const controls = useRef<{ target: THREE.Vector3; update: () => void } | null>(null);

  useEffect(() => {
    syncPieces(sim, pieces);
  }, [pieces, sim]);

  useEffect(() => {
    resetMarbles(sim);
    useEditor.getState().setHud({ score: 0, arrived: 0, lost: 0, active: 0 });
  }, [runToken, sim]);

  const focus = useMemo(() => focusOf(useEditor.getState().pieces), [viewToken]);

  useEffect(() => {
    const c = controls.current;
    if (!c) return;
    c.target.set(focus.x, Math.max(0.6, focus.y), focus.z);
    c.update();
  }, [focus]);

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.05);
    const playing = useEditor.getState().playing;
    sim.playing = playing;
    acc.current += dt;
    let guard = 0;
    while (acc.current >= 1 / 60 && guard < 4) {
      stepSim(sim, 1 / 60);
      acc.current -= 1 / 60;
      guard++;
      if (!useEditor.getState().muted) {
        for (const ev of sim.events) playCue(ev);
      }
    }
    const lead = sim.marbles.find((m) => m.mode === "rail" || m.mode === "flight" || m.mode === "zip");
    if (lead && light.current) {
      light.current.position.set(lead.pos.x, lead.pos.y + 0.55, lead.pos.z);
    }
    hudAcc.current += dt;
    if (hudAcc.current > 0.25) {
      hudAcc.current = 0;
      const s = useEditor.getState();
      const active = activeMarbles(sim);
      if (s.score !== sim.score || s.active !== active || s.arrived !== sim.arrived || s.lost !== sim.lost) {
        s.setHud({ score: sim.score, arrived: sim.arrived, lost: sim.lost, active });
      }
      if (playing && active === 0 && startsDone(sim) && sim.time > 0.5) {
        useEditor.setState({ playing: false });
      }
    }
  });

  const occupied = hover
    ? pieces.some((p) => p.q === hover.q && p.r === hover.r && p.level === brushLevel)
    : false;

  return (
    <>
      <Sky />
      <Stars />
      <hemisphereLight args={["#f4efe6", "#1a1030", 0.55]} />
      <ambientLight intensity={0.28} />
      <directionalLight position={[7, 12, 5]} intensity={1.25} color="#fff4e4" />
      <pointLight ref={light} position={[0, 3, 0]} intensity={8} distance={9} color={GOLD} />
      <fog attach="fog" args={["#09080f", 16, 40]} />
      <Pads />
      <Picker />
      {pieces.map((p) => (
        <PieceView key={p.id} piece={p} selected={p.id === selectedId} />
      ))}
      {hover && !occupied && <Ghost q={hover.q} r={hover.r} />}
      {hover && (
        <mesh position={[hexToXZ(hover.q, hover.r)[0], 0.06, hexToXZ(hover.q, hover.r)[1]]} rotation={[-Math.PI / 2, 0, Math.PI / 6]}>
          <ringGeometry args={[HEX_R * 0.72, HEX_R * 0.86, 6]} />
          <meshBasicMaterial color={occupied ? GOLD : TEAL} transparent opacity={0.8} />
        </mesh>
      )}
      <Marbles simRef={simRef} />
      <OrbitControls
        ref={controls as never}
        makeDefault
        enableDamping
        dampingFactor={0.12}
        maxPolarAngle={Math.PI / 2.08}
        minPolarAngle={0.22}
        minDistance={3.2}
        maxDistance={26}
        autoRotate={autoRotate}
        autoRotateSpeed={0.4}
      />
      <RingMark />
    </>
  );
}

function RingMark() {
  return (
    <mesh rotation={[Math.PI / 2.4, 0.2, 0.4]} position={[0, 6.5, -2]}>
      <torusGeometry args={[7.5, 0.012, 8, 64]} />
      <meshBasicMaterial color={GOLD} transparent opacity={0.35} />
    </mesh>
  );
}

export function Stage() {
  const viewToken = useEditor((s) => s.viewToken);
  const focus = useMemo(() => focusOf(useEditor.getState().pieces), [viewToken]);
  const [auto, setAuto] = useState(true);
  return (
    <Canvas
      className="h-full w-full touch-none"
      dpr={[1, 1.6]}
      camera={{
        position: [focus.x + 7.2, focus.y + 7.4, focus.z + 8.2],
        fov: 40,
        near: 0.1,
        far: 90,
      }}
      gl={{ antialias: true, alpha: false, powerPreference: "high-performance" }}
      onPointerDown={() => {
        unlockAudio();
        setAuto(false);
      }}
    >
      <color attach="background" args={["#09080f"]} />
      <World autoRotate={auto} />
    </Canvas>
  );
}
