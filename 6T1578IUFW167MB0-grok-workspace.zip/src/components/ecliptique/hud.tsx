import {
  Eraser,
  Minus,
  Pause,
  Play,
  Plus,
  RotateCcw,
  RotateCw,
  Trash2,
  Undo2,
  Volume2,
  VolumeX,
} from "lucide-react";
import { CATEGORIES, CATALOG, CHANNEL_COLORS, PIECES } from "@/game/catalog";
import { useEditor } from "@/game/store";

function onLaunch() {
  const s = useEditor.getState();
  if (s.playing) {
    s.togglePlay();
    return;
  }
  if (s.active === 0 && s.arrived + s.lost > 0) s.replay();
  else s.togglePlay();
}

export function Hud() {
  const cat = useEditor((s) => s.cat);
  const tool = useEditor((s) => s.tool);
  const mode = useEditor((s) => s.mode);
  const playing = useEditor((s) => s.playing);
  const score = useEditor((s) => s.score);
  const arrived = useEditor((s) => s.arrived);
  const lost = useEditor((s) => s.lost);
  const active = useEditor((s) => s.active);
  const muted = useEditor((s) => s.muted);
  const brushLevel = useEditor((s) => s.brushLevel);
  const selectedId = useEditor((s) => s.selectedId);
  const pieces = useEditor((s) => s.pieces);
  const confirmClear = useEditor((s) => s.confirmClear);
  const selected = pieces.find((p) => p.id === selectedId) ?? null;
  const def = selected ? CATALOG[selected.type] : CATALOG[tool];
  const list = PIECES.filter((p) => p.cat === cat);

  return (
    <div className="pointer-events-none absolute inset-0 flex flex-col">
      <header className="flex items-start justify-between gap-3 p-3 md:p-4">
        <div className="pointer-events-auto flex items-center gap-3">
          <span className="grid size-11 place-items-center rounded-lg bg-primary font-display text-lg text-bg">
            É
          </span>
          <div>
            <h1 className="font-display text-xl leading-none text-fg md:text-2xl">Écliptique</h1>
            <p className="mt-1 text-xs text-muted">Atelier de circuits de billes</p>
          </div>
        </div>
        <div className="pointer-events-auto flex flex-wrap items-center justify-end gap-2">
          <button
            type="button"
            onClick={onLaunch}
            className="inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-bg"
          >
            {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
            {playing ? "Pause" : arrived + lost > 0 && active === 0 ? "Relancer" : "Lancer"}
          </button>
          <IconBtn label="Recommencer les billes" onClick={() => useEditor.getState().replay()}>
            <RotateCcw className="size-4" />
          </IconBtn>
          <IconBtn label={muted ? "Son" : "Silence"} onClick={() => useEditor.getState().toggleMute()}>
            {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
          </IconBtn>
          <div className="rounded-lg border border-border bg-surface/90 px-3 py-2 text-right">
            <p className="font-display text-lg leading-none text-primary">{score}</p>
            <p className="mt-1 text-xs text-muted">
              {arrived} arrivées · {lost} perdues
            </p>
          </div>
        </div>
      </header>

      <div className="flex min-h-0 flex-1 items-stretch justify-between gap-3 px-3 md:px-4">
        <aside className="pointer-events-auto hidden w-64 shrink-0 flex-col gap-3 md:flex">
          <Palette cat={cat} tool={tool} mode={mode} list={list} />
        </aside>
        <div className="flex-1" />
        {def && (
          <aside className="pointer-events-auto hidden w-64 shrink-0 flex-col gap-3 self-start md:flex">
            <Inspector
              name={selected ? def.name : def.name}
              blurb={def.blurb}
              level={selected ? selected.level : brushLevel}
              selected={Boolean(selected)}
              channel={selected?.channel}
              showChannel={Boolean(selected && selected.type === "portail")}
              confirmClear={confirmClear}
            />
          </aside>
        )}
      </div>

      <footer className="pointer-events-auto flex flex-col gap-2 p-3 md:hidden">
        {selected && def && (
          <div className="flex items-center justify-between gap-2 rounded-lg border border-border bg-surface/90 px-3 py-2">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">{def.name}</p>
              <p className="truncate text-xs text-muted">Étage {selected.level}</p>
            </div>
            <div className="flex gap-2">
              <IconBtn label="Tourner" onClick={() => useEditor.getState().rotateSelected(1)}>
                <RotateCw className="size-4" />
              </IconBtn>
              <IconBtn label="Retirer" onClick={() => useEditor.getState().removeSelected()}>
                <Trash2 className="size-4" />
              </IconBtn>
            </div>
          </div>
        )}
        <div className="flex gap-2 overflow-x-auto pb-1">
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => useEditor.getState().setCat(c.id)}
              className={
                "h-11 shrink-0 rounded-lg border px-3 text-sm " +
                (cat === c.id ? "border-primary bg-primary text-bg" : "border-border bg-surface text-fg")
              }
            >
              {c.label}
            </button>
          ))}
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {list.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => useEditor.getState().setTool(p.id)}
              className={
                "h-11 shrink-0 rounded-lg border px-3 text-sm " +
                (tool === p.id && mode === "place"
                  ? "border-accent bg-surface text-accent"
                  : "border-border bg-bg text-fg")
              }
            >
              {p.name}
            </button>
          ))}
        </div>
      </footer>

      <p className="pointer-events-none absolute bottom-3 left-72 hidden text-xs text-muted md:block">
        Glisser pour orbiter · molette pour zoomer · clic pour poser · R tourne · Suppr retire
      </p>
    </div>
  );
}

function Palette({
  cat,
  tool,
  mode,
  list,
}: {
  cat: string;
  tool: string;
  mode: "place" | "erase";
  list: typeof PIECES;
}) {
  const brushLevel = useEditor((s) => s.brushLevel);
  return (
    <div className="flex max-h-full flex-col gap-3 overflow-hidden rounded-xl border border-border bg-surface/90 p-3">
      <div className="flex flex-wrap gap-1">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => useEditor.getState().setCat(c.id)}
            className={
              "h-9 rounded-md px-2 text-xs " +
              (cat === c.id ? "bg-primary text-bg" : "text-muted")
            }
          >
            {c.label}
          </button>
        ))}
      </div>
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs text-muted">Étage du pinceau</span>
        <div className="flex items-center gap-1">
          <IconBtn label="Étage inférieur" onClick={() => useEditor.getState().nudgeLevel(-1)}>
            <Minus className="size-4" />
          </IconBtn>
          <span className="w-6 text-center font-display text-lg text-fg">{brushLevel}</span>
          <IconBtn label="Étage supérieur" onClick={() => useEditor.getState().nudgeLevel(1)}>
            <Plus className="size-4" />
          </IconBtn>
        </div>
      </div>
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => useEditor.getState().setMode("place")}
          className={
            "h-10 flex-1 rounded-lg border text-sm " +
            (mode === "place" ? "border-accent text-accent" : "border-border text-muted")
          }
        >
          Poser
        </button>
        <button
          type="button"
          onClick={() => useEditor.getState().setMode(mode === "erase" ? "place" : "erase")}
          className={
            "inline-flex h-10 flex-1 items-center justify-center gap-2 rounded-lg border text-sm " +
            (mode === "erase" ? "border-danger text-danger" : "border-border text-muted")
          }
        >
          <Eraser className="size-4" />
          Gomme
        </button>
      </div>
      <div className="min-h-0 flex-1 space-y-1 overflow-y-auto pr-1">
        {list.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => useEditor.getState().setTool(p.id)}
            className={
              "flex w-full flex-col rounded-lg border px-3 py-2 text-left " +
              (tool === p.id && mode === "place"
                ? "border-primary bg-bg"
                : "border-transparent bg-bg/40")
            }
          >
            <span className="text-sm text-fg">{p.name}</span>
            <span className="text-xs leading-snug text-muted">{p.blurb}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function Inspector({
  name,
  blurb,
  level,
  selected,
  channel,
  showChannel,
  confirmClear,
}: {
  name: string;
  blurb: string;
  level: number;
  selected: boolean;
  channel?: number;
  showChannel: boolean;
  confirmClear: boolean;
}) {
  return (
    <div className="rounded-xl border border-border bg-surface/90 p-4">
      <p className="text-xs uppercase tracking-wide text-muted">{selected ? "Sélection" : "Pinceau"}</p>
      <h2 className="mt-1 font-display text-2xl leading-tight text-fg">{name}</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">{blurb}</p>
      <p className="mt-3 text-sm text-fg">Étage {level}</p>
      {showChannel && (
        <div className="mt-3 flex gap-2">
          {CHANNEL_COLORS.map((c, i) => (
            <button
              key={c}
              type="button"
              aria-label={`Teinte ${i + 1}`}
              onClick={() => useEditor.getState().setChannel(i)}
              className="size-8 rounded-full border"
              style={{
                background: c,
                borderColor: channel === i ? "var(--color-fg)" : "transparent",
              }}
            />
          ))}
        </div>
      )}
      <div className="mt-4 flex flex-wrap gap-2">
        <IconBtn label="Tourner" onClick={() => useEditor.getState().rotateSelected(1)}>
          <RotateCw className="size-4" />
        </IconBtn>
        <IconBtn label="Étage inférieur" onClick={() => useEditor.getState().nudgeLevel(-1)}>
          <Minus className="size-4" />
        </IconBtn>
        <IconBtn label="Étage supérieur" onClick={() => useEditor.getState().nudgeLevel(1)}>
          <Plus className="size-4" />
        </IconBtn>
        {selected && (
          <IconBtn label="Retirer la pièce" onClick={() => useEditor.getState().removeSelected()}>
            <Trash2 className="size-4" />
          </IconBtn>
        )}
        <IconBtn label="Annuler" onClick={() => useEditor.getState().undoOnce()}>
          <Undo2 className="size-4" />
        </IconBtn>
      </div>
      <div className="mt-4 flex flex-col gap-2">
        <button
          type="button"
          onClick={() => useEditor.getState().loadDream()}
          className="h-10 rounded-lg border border-border text-sm text-fg"
        >
          Songe d'origine
        </button>
        <button
          type="button"
          onClick={() => useEditor.getState().loadMuseum()}
          className="h-10 rounded-lg border border-border text-sm text-fg"
        >
          Musée des pièces
        </button>
        <button
          type="button"
          onClick={() => {
            if (confirmClear) useEditor.getState().clearAll();
            else useEditor.getState().armClear();
          }}
          className="h-10 rounded-lg border border-danger text-sm text-danger"
        >
          {confirmClear ? "Confirmer l'effacement" : "Effacer le plateau"}
        </button>
      </div>
    </div>
  );
}

function IconBtn({
  children,
  label,
  onClick,
}: {
  children: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className="grid size-11 place-items-center rounded-lg border border-border bg-surface text-fg"
    >
      {children}
    </button>
  );
}
