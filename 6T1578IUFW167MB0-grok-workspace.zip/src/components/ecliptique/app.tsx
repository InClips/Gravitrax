import { useEffect } from "react";
import { unlockAudio } from "@/game/audio";
import { useEditor } from "@/game/store";
import { Hud } from "./hud";
import { Stage } from "./scene";

export default function App() {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      const ed = useEditor.getState();
      if (e.code === "Space") {
        e.preventDefault();
        unlockAudio();
        if (ed.playing) ed.togglePlay();
        else if (ed.active === 0 && ed.arrived + ed.lost > 0) ed.replay();
        else ed.togglePlay();
      } else if (e.code === "KeyR") {
        ed.rotateSelected(e.shiftKey ? -1 : 1);
      } else if (e.code === "Backspace" || e.code === "Delete") {
        ed.removeSelected();
      } else if (e.code === "KeyZ" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        ed.undoOnce();
      } else if (e.code === "BracketLeft") {
        ed.nudgeLevel(-1);
      } else if (e.code === "BracketRight") {
        ed.nudgeLevel(1);
      } else if (e.code === "Escape") {
        ed.select(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <Stage />
      <Hud />
    </div>
  );
}
