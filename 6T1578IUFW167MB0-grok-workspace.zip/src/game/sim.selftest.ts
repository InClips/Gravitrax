import { PIECES } from "./catalog";
import { buildDream, buildMuseum } from "./layouts";
import { activeMarbles, createSim, stepSim } from "./sim";

const dream = buildDream();
const museum = buildMuseum();
const sim = createSim(dream);
sim.playing = true;

for (let i = 0; i < 60 * 26; i++) stepSim(sim, 1 / 60);

const report = {
  pieces: dream.length,
  catalog: PIECES.length,
  museum: museum.length,
  museumUnique: new Set(museum.map((p) => `${p.q},${p.r}`)).size,
  arrived: sim.arrived,
  lost: sim.lost,
  active: activeMarbles(sim),
  score: sim.score,
  modes: sim.marbles.map((m) => m.mode),
};

console.log(JSON.stringify(report, null, 2));

if (sim.arrived < 3) {
  const alive = sim.marbles
    .filter((m) => m.mode !== "gone")
    .map((m) => ({
      mode: m.mode,
      t: +m.t.toFixed(2),
      sp: +m.speed.toFixed(2),
      x: +m.pos.x.toFixed(2),
      y: +m.pos.y.toFixed(2),
      z: +m.pos.z.toFixed(2),
      piece: m.pieceId,
      g: m.gSign,
    }));
  console.log("alive", JSON.stringify(alive, null, 2));
  process.exit(1);
}

console.log("sim ok");
