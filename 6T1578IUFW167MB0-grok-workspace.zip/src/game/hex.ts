export type Port = 0 | 1 | 2 | 3 | 4 | 5;

export const HEX_R = 0.96;
export const HEX_SPACING = Math.sqrt(3) * HEX_R;
export const EDGE = HEX_SPACING / 2;
export const LEVEL_H = 0.86;
export const RAIL_LIFT = 0.2;
export const GRAV = 11;

/** Pointy-top axial neighbors, direction 0 = +X, then +60° toward +Z. */
export const NEI: ReadonlyArray<readonly [number, number]> = [
  [1, 0],
  [0, 1],
  [-1, 1],
  [-1, 0],
  [0, -1],
  [1, -1],
];

export function mod(n: number, m: number): number {
  return ((n % m) + m) % m;
}

export function hexToXZ(q: number, r: number): [number, number] {
  const x = HEX_SPACING * (q + r / 2);
  const z = HEX_SPACING * (Math.sqrt(3) / 2) * r;
  return [x, z];
}

export function axialRound(q: number, r: number): { q: number; r: number } {
  const x = q;
  const z = r;
  const y = -x - z;
  let rx = Math.round(x);
  let ry = Math.round(y);
  let rz = Math.round(z);
  const xd = Math.abs(rx - x);
  const yd = Math.abs(ry - y);
  const zd = Math.abs(rz - z);
  if (xd > yd && xd > zd) rx = -ry - rz;
  else if (yd > zd) ry = -rx - rz;
  else rz = -rx - ry;
  return { q: rx, r: rz };
}

export function worldToAxial(x: number, z: number): { q: number; r: number } {
  const r = z / (HEX_SPACING * (Math.sqrt(3) / 2));
  const q = x / HEX_SPACING - r / 2;
  return axialRound(q, r);
}

export function hexesInRadius(radius: number): Array<[number, number]> {
  const out: Array<[number, number]> = [];
  for (let q = -radius; q <= radius; q++) {
    for (let r = -radius; r <= radius; r++) {
      const s = -q - r;
      if (Math.max(Math.abs(q), Math.abs(r), Math.abs(s)) <= radius) out.push([q, r]);
    }
  }
  return out;
}

export type V3 = { x: number; y: number; z: number };

export function socketPos(q: number, r: number, level: number, port: number): V3 {
  const [x, z] = hexToXZ(q, r);
  const ang = port * (Math.PI / 3);
  return {
    x: x + Math.cos(ang) * EDGE,
    y: level * LEVEL_H + RAIL_LIFT,
    z: z + Math.sin(ang) * EDGE,
  };
}

export function cellCenter(q: number, r: number, level: number): V3 {
  const [x, z] = hexToXZ(q, r);
  return { x, y: level * LEVEL_H + RAIL_LIFT, z };
}

export function dist3(a: V3, b: V3): number {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  const dz = a.z - b.z;
  return Math.hypot(dx, dy, dz);
}

export const GRID = hexesInRadius(10);
export const GRID_LIMIT = 10;
