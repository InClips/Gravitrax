import { CATALOG, PIECES } from "./catalog";
import { GRID_LIMIT, LEVEL_H, NEI, hexToXZ, hexesInRadius, mod } from "./hex";
import type { Placed } from "./sim";

type Cursor = {
  q: number;
  r: number;
  level: number;
  heading: number;
  tipQ: number;
  tipR: number;
};

function builder() {
  const pieces: Placed[] = [];
  const used = new Set<string>();
  let n = 1;
  let cur: Cursor = { q: 0, r: 0, level: 0, heading: 0, tipQ: 0, tipR: 0 };

  function occupy(q: number, r: number, level: number, type: string) {
    if (Math.max(Math.abs(q), Math.abs(r), Math.abs(-q - r)) > GRID_LIMIT) {
      throw new Error(`hors grille ${type} @ ${q},${r}`);
    }
    const key = `${q},${r},${level}`;
    if (used.has(key)) throw new Error(`occupé ${key} par ${type}`);
    used.add(key);
  }

  function start(q: number, r: number, level: number, heading: number) {
    occupy(q, r, level, "depart");
    pieces.push({ id: `s${n++}`, type: "depart", q, r, level, rot: heading });
    const [dq, dr] = NEI[heading]!;
    cur = { q, r, level, heading, tipQ: q + dq, tipR: r + dr };
  }

  function lay(type: string, turn = 0) {
    const def = CATALOG[type];
    if (!def) throw new Error(`type ${type}`);
    const entryWorld = mod(cur.heading + 3, 6);
    const newHeading = mod(cur.heading + turn, 6);
    for (let rot = 0; rot < 6; rot++) {
      for (const link of def.links) {
        if (mod(link.from + rot, 6) !== entryWorld) continue;
        if (mod(link.to + rot, 6) !== newHeading) continue;
        const base = cur.level - link.fromDy;
        const exitLevel = base + link.toDy;
        if (base < 0 || base > 6 || exitLevel < 0 || exitLevel > 6) continue;
        occupy(cur.tipQ, cur.tipR, base, type);
        pieces.push({ id: `s${n++}`, type, q: cur.tipQ, r: cur.tipR, level: base, rot });
        const [dq, dr] = NEI[newHeading]!;
        cur = {
          q: cur.tipQ,
          r: cur.tipR,
          level: exitLevel,
          heading: newHeading,
          tipQ: cur.tipQ + dq,
          tipR: cur.tipR + dr,
        };
        return;
      }
    }
    throw new Error(`ajustement impossible: ${type} cap ${cur.heading} niv ${cur.level} tour ${turn}`);
  }

  function layDrop(depth: 1 | 2) {
    const type = depth === 1 ? "chute" : "chute2";
    occupy(cur.tipQ, cur.tipR, cur.level, type);
    const rot = cur.heading;
    pieces.push({ id: `s${n++}`, type, q: cur.tipQ, r: cur.tipR, level: cur.level, rot });
    cur = {
      q: cur.tipQ,
      r: cur.tipR,
      level: cur.level - depth,
      heading: cur.heading,
      tipQ: cur.tipQ,
      tipR: cur.tipR,
    };
  }

  function layBowl(type = "receptacle") {
    occupy(cur.tipQ, cur.tipR, cur.level, type);
    const rot = cur.heading;
    pieces.push({ id: `s${n++}`, type, q: cur.tipQ, r: cur.tipR, level: cur.level, rot });
    const [dq, dr] = NEI[cur.heading]!;
    cur = {
      q: cur.tipQ,
      r: cur.tipR,
      level: cur.level,
      heading: cur.heading,
      tipQ: cur.tipQ + dq,
      tipR: cur.tipR + dr,
    };
  }

  function layGoal(type = "carillon") {
    occupy(cur.tipQ, cur.tipR, cur.level, type);
    pieces.push({
      id: `s${n++}`,
      type,
      q: cur.tipQ,
      r: cur.tipR,
      level: cur.level,
      rot: cur.heading,
    });
  }

  function decorate(type: string, q: number, r: number, level: number, rot: number, channel?: number) {
    const key = `${q},${r},${level}`;
    if (used.has(key)) return;
    if (Math.max(Math.abs(q), Math.abs(r), Math.abs(-q - r)) > GRID_LIMIT) return;
    used.add(key);
    pieces.push({ id: `s${n++}`, type, q, r, level, rot, channel });
  }

  return { pieces, start, lay, layDrop, layBowl, layGoal, decorate, cursor: () => cur };
}

/** A playable dream run: slopes, loop, well, then a bell. */
export function buildDream(): Placed[] {
  const b = builder();
  b.start(-2, -2, 4, 0);
  b.lay("souffle");
  b.lay("droit");
  b.lay("courbe", 1);
  b.lay("tunnel");
  b.lay("descente");
  b.lay("serpent");
  b.lay("courbe", 1);
  b.lay("spirale");
  b.lay("souffle");
  b.lay("looping");
  b.lay("courbe", -1);
  b.lay("pont");
  b.lay("nebuleuse");
  b.lay("courbe", -1);
  b.lay("tube");
  b.layDrop(1);
  b.layBowl("receptacle");
  b.lay("constellation", 1);
  b.layGoal("carillon");

  // Side relics — not on the critical path, so the run always finishes.
  b.decorate("volcan", -2, 3, 1, 1);
  b.decorate("canon", -3, 2, 2, 0);
  b.decorate("portail", 3, -3, 1, 2, 0);
  b.decorate("portail", -4, -1, 2, 4, 0);
  b.decorate("prisme", 2, 3, 1, 0);
  b.decorate("trou", -2, -3, 0, 0);
  b.decorate("lune", 4, 2, 2, 1);
  return b.pieces;
}

function cubeDist(q1: number, r1: number, q2: number, r2: number): number {
  return Math.max(Math.abs(q1 - q2), Math.abs(r1 - r2), Math.abs(q1 + r1 - (q2 + r2)));
}

export function buildMuseum(): Placed[] {
  const spots: Array<[number, number]> = [];
  for (const [q, r] of hexesInRadius(10)) {
    if (spots.every(([oq, or]) => cubeDist(q, r, oq, or) >= 2)) spots.push([q, r]);
  }
  let portalN = 0;
  return PIECES.map((def, i) => {
    const spot = spots[i] ?? spots[i % Math.max(1, spots.length)] ?? [0, 0];
    const piece: Placed = {
      id: `m${i}`,
      type: def.id,
      q: spot[0],
      r: spot[1],
      level: def.id === "spirale" || def.id === "elevateur" ? 2 : 0,
      rot: 0,
    };
    if (def.id === "portail") piece.channel = Math.floor(portalN++ / 2);
    return piece;
  });
}

export function focusOf(pieces: Placed[]): { x: number; y: number; z: number } {
  if (!pieces.length) return { x: 0, y: 1, z: 0 };
  let x = 0;
  let y = 0;
  let z = 0;
  for (const p of pieces) {
    const [px, pz] = hexToXZ(p.q, p.r);
    x += px;
    z += pz;
    y += p.level * LEVEL_H;
  }
  const n = pieces.length;
  return { x: x / n, y: y / n + 0.4, z: z / n };
}

export function nextPortalChannel(pieces: Placed[]): number {
  const counts = [0, 0, 0, 0, 0, 0];
  for (const p of pieces) {
    if (p.type === "portail" && p.channel != null && p.channel >= 0 && p.channel < 6) {
      counts[p.channel]!++;
    }
  }
  const odd = counts.findIndex((c) => c % 2 === 1);
  if (odd >= 0) return odd;
  return counts.findIndex((c) => c === 0) >= 0 ? counts.findIndex((c) => c === 0) : 0;
}
