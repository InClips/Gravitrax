import {
  CATALOG,
  MARBLE_COLORS,
  socketDy,
  type Behavior,
  type Def,
  type Link,
  type Profile,
} from "./catalog";
import {
  EDGE,
  GRAV,
  LEVEL_H,
  NEI,
  RAIL_LIFT,
  cellCenter,
  dist3,
  hexToXZ,
  mod,
  socketPos,
  type Port,
  type V3,
} from "./hex";

export type Placed = {
  id: string;
  type: string;
  q: number;
  r: number;
  level: number;
  rot: number;
  channel?: number;
};

export type Ride = {
  pieceId: string;
  q: number;
  r: number;
  from: Port;
  to: Port;
  fromLevel: number;
  toLevel: number;
  profile: Profile;
  friction: number;
  kick: number;
  trail: boolean;
  flip: boolean;
};

export type Marble = {
  id: number;
  color: string;
  mode: "rail" | "flight" | "wait" | "bowl" | "orbit" | "zip" | "swallowed" | "gone";
  pos: V3;
  vel: V3;
  speed: number;
  t: number;
  gSign: number;
  hide: boolean;
  trail: boolean;
  ignore: number;
  ignoreId: string;
  wait: number;
  pieceId: string;
  ride: Ride | null;
  ang: number;
  fresh: boolean;
  /** gate / hold / orbit bookkeeping */
  aux: number;
  auxPort: Port;
};

export type Fx = {
  x: number;
  y: number;
  z: number;
  life: number;
  max: number;
  color: string;
  vx: number;
  vy: number;
  vz: number;
};

type Inst = Placed & { def: Def };

type Rt = { spawned: number; cool: number; toggle: number };

export type Sim = {
  pieces: Inst[];
  byId: Map<string, Inst>;
  index: Map<string, Inst[]>;
  marbles: Marble[];
  fx: Fx[];
  events: string[];
  time: number;
  playing: boolean;
  score: number;
  arrived: number;
  lost: number;
  nextId: number;
  seed: number;
  colorI: number;
};

const LOOP_R = 0.28;

export function createSim(placed: Placed[]): Sim {
  const sim: Sim = {
    pieces: [],
    byId: new Map(),
    index: new Map(),
    marbles: [],
    fx: [],
    events: [],
    time: 0,
    playing: false,
    score: 0,
    arrived: 0,
    lost: 0,
    nextId: 1,
    seed: 0xec11,
    colorI: 0,
  };
  syncPieces(sim, placed);
  return sim;
}

export function syncPieces(sim: Sim, placed: Placed[]) {
  const rtKeep = new Map<string, Rt>();
  for (const p of sim.pieces) {
    const prev = (p as Inst & { rt?: Rt }).rt;
    if (prev) rtKeep.set(p.id, prev);
  }
  const pieces: Inst[] = [];
  for (const p of placed) {
    const def = CATALOG[p.type];
    if (!def) continue;
    const inst = { ...p, def, rt: rtKeep.get(p.id) ?? { spawned: 0, cool: 0.35, toggle: 0 } } as Inst & {
      rt: Rt;
    };
    pieces.push(inst);
  }
  sim.pieces = pieces;
  sim.byId = new Map(pieces.map((p) => [p.id, p]));
  const index = new Map<string, Inst[]>();
  for (const p of pieces) {
    const k = `${p.q},${p.r}`;
    const arr = index.get(k);
    if (arr) arr.push(p);
    else index.set(k, [p]);
  }
  sim.index = index;
}

function rtOf(p: Inst): Rt {
  return (p as Inst & { rt: Rt }).rt;
}

export function resetMarbles(sim: Sim) {
  sim.marbles = [];
  sim.fx = [];
  sim.score = 0;
  sim.arrived = 0;
  sim.lost = 0;
  sim.time = 0;
  sim.colorI = 0;
  sim.nextId = 1;
  for (const p of sim.pieces) {
    const rt = rtOf(p);
    rt.spawned = 0;
    rt.cool = 0.2;
    rt.toggle = 0;
  }
}

function rng(sim: Sim): number {
  sim.seed = (Math.imul(sim.seed, 1664525) + 1013904223) >>> 0;
  return sim.seed / 4294967296;
}

function nextColor(sim: Sim): string {
  const c = MARBLE_COLORS[sim.colorI % MARBLE_COLORS.length]!;
  sim.colorI++;
  return c;
}

function makeMarble(sim: Sim, pos: V3): Marble {
  return {
    id: sim.nextId++,
    color: nextColor(sim),
    mode: "flight",
    pos: { ...pos },
    vel: { x: 0, y: 0, z: 0 },
    speed: 0,
    t: 0,
    gSign: 1,
    hide: false,
    trail: false,
    ignore: 0,
    ignoreId: "",
    wait: 0,
    pieceId: "",
    ride: null,
    ang: 0,
    fresh: true,
    aux: 0,
    auxPort: 0,
  };
}

export function sampleRide(ride: Ride, t: number): V3 {
  const A = socketPos(ride.q, ride.r, ride.fromLevel, ride.from);
  const B = socketPos(ride.q, ride.r, ride.toLevel, ride.to);
  const [cx, cz] = hexToXZ(ride.q, ride.r);
  const tt = Math.min(1, Math.max(0, t));

  if (ride.profile === "drop") {
    const lowY = ride.toLevel * 1 + 0; // encoded below
    if (tt < 0.48) {
      const k = tt / 0.48;
      return { x: A.x + (cx - A.x) * k, y: A.y, z: A.z + (cz - A.z) * k };
    }
    const k = (tt - 0.48) / 0.52;
    return { x: cx, y: A.y + (ride.toLevel - A.y) * k, z: cz };
  }

  if (ride.profile === "spiral") {
    const turns = 1.2;
    const a0 = ride.from * (Math.PI / 3);
    const spin = a0 + tt * turns * Math.PI * 2;
    const rad = EDGE * (0.78 - 0.25 * tt);
    let x = cx + Math.cos(spin) * rad;
    let z = cz + Math.sin(spin) * rad;
    let y = A.y + (B.y - A.y) * tt;
    if (tt > 0.72) {
      const k = (tt - 0.72) / 0.28;
      const s = k * k * (3 - 2 * k);
      x += (B.x - x) * s;
      z += (B.z - z) * s;
      y += (B.y - y) * s;
    }
    return { x, y, z };
  }

  if (ride.profile === "lift") {
    if (tt < 0.68) {
      const k = tt / 0.68;
      return {
        x: A.x + (cx - A.x) * k,
        y: A.y + (B.y - A.y) * k,
        z: A.z + (cz - A.z) * k,
      };
    }
    const k = (tt - 0.68) / 0.32;
    return { x: cx + (B.x - cx) * k, y: B.y, z: cz + (B.z - cz) * k };
  }

  const dPort = Math.min(mod(ride.to - ride.from, 6), mod(ride.from - ride.to, 6));
  const pull = dPort === 0 ? 0.85 : dPort === 3 ? 0 : dPort === 2 ? 0.58 : 0.75;
  const mid = { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2, z: (A.z + B.z) / 2 };
  const ctrl = {
    x: mid.x + (cx - mid.x) * pull,
    y: mid.y,
    z: mid.z + (cz - mid.z) * pull,
  };
  const u = 1 - tt;
  let x = u * u * A.x + 2 * u * tt * ctrl.x + tt * tt * B.x;
  let y = u * u * A.y + 2 * u * tt * ctrl.y + tt * tt * B.y;
  let z = u * u * A.z + 2 * u * tt * ctrl.z + tt * tt * B.z;

  if (ride.profile === "wave" || ride.profile === "tunnel") {
    y += Math.sin(tt * Math.PI * 2) * (ride.profile === "wave" ? 0.07 : 0.02);
  } else if (ride.profile === "hump") {
    y += Math.sin(tt * Math.PI) * 0.2;
  } else if (ride.profile === "dip") {
    y -= Math.sin(tt * Math.PI) * 0.46;
  } else if (ride.profile === "loop") {
    const theta = tt * Math.PI * 2;
    const dx = B.x - A.x;
    const dz = B.z - A.z;
    const len = Math.hypot(dx, dz) || 1;
    x += (dx / len) * Math.sin(theta) * LOOP_R;
    z += (dz / len) * Math.sin(theta) * LOOP_R;
    y += (1 - Math.cos(theta)) * LOOP_R;
  }
  return { x, y, z };
}

function beginLink(m: Marble, p: Inst, link: Link, t0 = 0) {
  const fromLevel = p.level + link.fromDy;
  const toLevel = p.level + link.toDy;
  m.mode = "rail";
  m.hide = false;
  m.t = t0;
  m.pieceId = p.id;
  m.ride = {
    pieceId: p.id,
    q: p.q,
    r: p.r,
    from: mod(link.from + p.rot, 6) as Port,
    to: mod(link.to + p.rot, 6) as Port,
    fromLevel,
    toLevel,
    profile: link.profile,
    friction: link.friction,
    kick: link.kick,
    trail: link.trail || p.def.trail,
    flip: p.def.flipOnExit,
  };
  m.speed = Math.max(m.speed, 0.35) + link.kick;
  if (m.ride.trail) m.trail = true;
  m.pos = sampleRide(m.ride, m.t);
  if (link.profile === "vortex") m.speed = Math.min(m.speed, 0.7);
}

function beginSynthetic(
  m: Marble,
  p: Inst,
  fromLocal: Port,
  toLocal: Port,
  profile: Profile,
  friction: number,
  kick: number,
) {
  beginLink(
    m,
    p,
    {
      from: fromLocal,
      to: toLocal,
      profile,
      fromDy: socketDy(p.def, fromLocal),
      toDy: socketDy(p.def, toLocal),
      friction,
      kick,
      trail: p.def.trail,
    },
    0,
  );
}

function localPort(p: Inst, world: number): Port {
  return mod(world - p.rot, 6) as Port;
}

function accepts(p: Inst, worldPort: number, level: number): boolean {
  const local = localPort(p, worldPort);
  const sock = p.def.sockets.find((s) => s.port === local);
  if (!sock) return false;
  if (p.level + sock.dy !== level) return false;
  return behaviorAccepts(p.def.behavior, local, p.def);
}

function behaviorAccepts(b: Behavior, local: Port, def: Def): boolean {
  switch (b.kind) {
    case "rails":
    case "start":
      return def.links.some((l) => l.from === local);
    case "goal":
    case "fountain":
    case "portal":
    case "hole":
      return true;
    case "launcher":
    case "zip":
    case "switch":
    case "random":
    case "timed":
    case "gate":
    case "hold":
    case "clone":
    case "split":
    case "orbit":
      return b.entry === local;
    case "drop":
      return true;
    case "mixer":
      return b.ports.includes(local);
    case "bumper":
      return def.links.some((l) => l.from === local);
    default:
      return false;
  }
}

function findAt(sim: Sim, q: number, r: number, worldPort: number, level: number): Inst | null {
  const arr = sim.index.get(`${q},${r}`);
  if (!arr) return null;
  for (const p of arr) if (accepts(p, worldPort, level)) return p;
  return null;
}

function burst(sim: Sim, pos: V3, color: string, n = 8) {
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + rng(sim);
    sim.fx.push({
      x: pos.x,
      y: pos.y,
      z: pos.z,
      vx: Math.cos(a) * (0.6 + rng(sim)),
      vy: 0.8 + rng(sim) * 1.4,
      vz: Math.sin(a) * (0.6 + rng(sim)),
      life: 0.55 + rng(sim) * 0.3,
      max: 0.7,
      color,
    });
  }
}

function consume(sim: Sim, m: Marble, points: number) {
  if (m.mode === "gone") return;
  burst(sim, m.pos, m.color, 10);
  sim.events.push("goal");
  sim.score += points;
  sim.arrived += 1;
  m.mode = "gone";
  m.hide = true;
  m.ride = null;
}

function lose(sim: Sim, m: Marble) {
  if (m.mode === "gone") return;
  m.mode = "gone";
  m.hide = true;
  m.ride = null;
  sim.lost += 1;
  sim.events.push("lost");
}

function flyFrom(m: Marble, pos: V3, worldPort: number, speed: number, ignoreId: string) {
  const ang = worldPort * (Math.PI / 3);
  const sp = Math.max(speed, 1.1);
  m.mode = "flight";
  m.ride = null;
  m.hide = false;
  m.pos = { ...pos };
  m.vel = { x: Math.cos(ang) * sp, y: 0.35, z: Math.sin(ang) * sp };
  m.ignoreId = ignoreId;
  m.ignore = 0.28;
  m.pieceId = ignoreId;
}

function handoff(sim: Sim, m: Marble, q: number, r: number, worldExit: number, level: number, speed: number) {
  const nq = q + NEI[worldExit]![0];
  const nr = r + NEI[worldExit]![1];
  const entry = mod(worldExit + 3, 6);
  const hit = findAt(sim, nq, nr, entry, level);
  if (!hit) {
    flyFrom(m, socketPos(q, r, level, worldExit), worldExit, speed, m.pieceId);
    return;
  }
  enterPiece(sim, m, hit, entry, speed);
}

function enterPiece(sim: Sim, m: Marble, p: Inst, worldPort: number, speed: number) {
  const local = localPort(p, worldPort);
  const b = p.def.behavior;
  m.pieceId = p.id;
  m.speed = speed;
  m.ignoreId = p.id;
  m.ignore = 0.12;
  m.hide = false;

  switch (b.kind) {
    case "rails":
    case "start":
    case "bumper": {
      const link = p.def.links.find((l) => l.from === local);
      if (!link) {
        flyFrom(m, m.pos, worldPort, speed, p.id);
        return;
      }
      beginLink(m, p, link, 0);
      return;
    }
    case "goal":
      m.pos = cellCenter(p.q, p.r, p.level);
      consume(sim, m, p.def.id === "carillon" ? 150 : 100);
      return;
    case "fountain": {
      m.pos = cellCenter(p.q, p.r, p.level);
      consume(sim, m, 120);
      if (rng(sim) < 0.45 && sim.marbles.length < 18) {
        const baby = makeMarble(sim, cellCenter(p.q, p.r, p.level));
        baby.mode = "flight";
        baby.vel = { x: (rng(sim) - 0.5) * 1.4, y: 4.2, z: (rng(sim) - 0.5) * 1.4 };
        baby.ignoreId = p.id;
        baby.ignore = 0.35;
        baby.gSign = m.gSign;
        sim.marbles.push(baby);
        sim.events.push("spawn");
      }
      return;
    }
    case "launcher": {
      if (local !== b.entry) {
        flyFrom(m, m.pos, worldPort, speed, p.id);
        return;
      }
      m.mode = "wait";
      m.wait = b.delay;
      m.aux = 1; // launch
      m.auxPort = mod(b.heading + p.rot, 6) as Port;
      m.pos = cellCenter(p.q, p.r, p.level);
      m.ride = null;
      // stash power/lift in speed/ang temporarily via marble fields: speed=power, ang=lift
      m.speed = b.power;
      m.ang = b.lift;
      return;
    }
    case "drop": {
      const depth = b.depth;
      const fromLevel = p.level + socketDy(p.def, local);
      const targetY = (p.level - depth) * LEVEL_H + RAIL_LIFT + 0.45;
      m.mode = "rail";
      m.t = 0;
      m.ride = {
        pieceId: p.id,
        q: p.q,
        r: p.r,
        from: mod(local + p.rot, 6) as Port,
        to: mod(local + p.rot, 6) as Port,
        fromLevel,
        toLevel: targetY,
        profile: "drop",
        friction: 0.02,
        kick: 0,
        trail: false,
        flip: false,
      };
      m.speed = Math.max(speed, 1.4);
      m.pos = sampleRide(m.ride, 0);
      return;
    }
    case "zip": {
      const heading = mod(b.heading + p.rot, 6);
      const ang = heading * (Math.PI / 3);
      m.mode = "zip";
      m.ride = null;
      m.pos = cellCenter(p.q, p.r, p.level);
      m.pos.x += Math.cos(ang) * 0.2;
      m.pos.z += Math.sin(ang) * 0.2;
      m.vel = { x: Math.cos(ang) * 5.4, y: -0.42, z: Math.sin(ang) * 5.4 };
      m.wait = 0;
      m.auxPort = heading as Port;
      sim.events.push("launch");
      return;
    }
    case "switch":
    case "random":
    case "timed": {
      if (local !== b.entry) {
        flyFrom(m, m.pos, worldPort, speed, p.id);
        return;
      }
      const exits = b.exits;
      let idx = 0;
      if (b.kind === "switch") {
        const rt = rtOf(p);
        idx = rt.toggle % exits.length;
        rt.toggle++;
      } else if (b.kind === "random") {
        idx = Math.floor(rng(sim) * exits.length);
      } else {
        idx = Math.floor(sim.time / b.period) % exits.length;
      }
      const exit = exits[idx] ?? exits[0]!;
      beginSynthetic(m, p, b.entry, exit, "flat", 0.2, 0.3);
      m.speed = Math.max(speed, 1.3);
      return;
    }
    case "gate": {
      const open = Math.sin(sim.time * 1.7) > -0.2;
      if (!open) {
        m.mode = "wait";
        m.wait = 0;
        m.aux = 2;
        m.auxPort = b.exit;
        m.pos = socketPos(p.q, p.r, p.level + socketDy(p.def, local), mod(local + p.rot, 6));
        m.ride = null;
        m.speed = speed;
        return;
      }
      beginSynthetic(m, p, b.entry, b.exit, "flat", 0.2, 0.2);
      m.speed = Math.max(speed, 1.2);
      return;
    }
    case "portal": {
      const pair = sim.pieces.find(
        (o) => o.def.id === "portail" && o.id !== p.id && (o.channel ?? 0) === (p.channel ?? 0),
      );
      burst(sim, cellCenter(p.q, p.r, p.level), m.color, 6);
      sim.events.push("portal");
      if (!pair) {
        m.mode = "orbit";
        m.wait = 0;
        m.ang = rng(sim) * Math.PI * 2;
        m.aux = 1.1;
        m.pieceId = p.id;
        m.ride = null;
        return;
      }
      const out = mod(0 + pair.rot, 6);
      const level = pair.level + socketDy(pair.def, 0);
      m.pos = cellCenter(pair.q, pair.r, pair.level);
      burst(sim, m.pos, m.color, 6);
      m.ignoreId = pair.id;
      m.ignore = 0.2;
      handoff(sim, m, pair.q, pair.r, out, level, Math.max(speed, 2.6));
      return;
    }
    case "split":
    case "clone": {
      if (local !== b.entry) {
        flyFrom(m, m.pos, worldPort, speed, p.id);
        return;
      }
      const exits = b.exits;
      beginSynthetic(m, p, b.entry, exits[0]!, "flat", 0.16, 0.4);
      m.speed = Math.max(speed, 1.8);
      for (let i = 1; i < exits.length; i++) {
        if (sim.marbles.length >= 18) break;
        const c = makeMarble(sim, cellCenter(p.q, p.r, p.level));
        c.gSign = m.gSign;
        c.trail = true;
        beginSynthetic(c, p, b.entry, exits[i]!, "flat", 0.16, 0.3 + i * 0.15);
        c.speed = Math.max(speed, 1.7);
        c.fresh = true;
        sim.marbles.push(c);
      }
      sim.events.push("spawn");
      return;
    }
    case "hold": {
      if (local !== b.entry) {
        flyFrom(m, m.pos, worldPort, speed, p.id);
        return;
      }
      m.mode = "wait";
      m.wait = b.delay;
      m.aux = 3;
      m.auxPort = b.exit;
      m.hide = true;
      m.pos = cellCenter(p.q, p.r, p.level);
      m.speed = speed;
      m.ride = null;
      return;
    }
    case "mixer": {
      if (!b.ports.includes(local) && !p.def.catchCenter) {
        flyFrom(m, m.pos, worldPort, speed, p.id);
        return;
      }
      m.mode = "bowl";
      m.wait = 0;
      m.ang = rng(sim) * Math.PI * 2;
      m.ride = null;
      m.pos = cellCenter(p.q, p.r, p.level);
      m.auxPort = local;
      return;
    }
    case "hole": {
      m.mode = "swallowed";
      m.hide = true;
      m.wait = 1.05;
      m.ride = null;
      m.pos = cellCenter(p.q, p.r, p.level);
      burst(sim, m.pos, "#e25b6a", 8);
      sim.events.push("drop");
      return;
    }
    case "orbit": {
      if (local !== b.entry && local !== b.exit) {
        // still allow
      }
      m.mode = "orbit";
      m.wait = 0;
      m.aux = b.time;
      m.ang = 0;
      m.auxPort = b.exit;
      m.ride = null;
      m.speed = speed;
      return;
    }
    default:
      return;
  }
}

function catchToPiece(sim: Sim, m: Marble, p: Inst, speedHint: number) {
  if (p.def.behavior.kind === "goal" || p.def.behavior.kind === "fountain") {
    m.pos = cellCenter(p.q, p.r, p.level);
    enterPiece(sim, m, p, mod(0 + p.rot, 6), speedHint);
    return;
  }
  if (p.def.behavior.kind === "hole" || p.def.behavior.kind === "portal" || p.def.behavior.kind === "mixer") {
    const local = p.def.behavior.kind === "mixer" ? p.def.behavior.ports[0]! : (3 as Port);
    enterPiece(sim, m, p, mod(local + p.rot, 6), speedHint);
    return;
  }
  const out = p.def.outLocal;
  const link = p.def.links.find((l) => l.to === out) ?? p.def.links[0];
  if (!link) {
    const worldOut = mod(out + p.rot, 6);
    handoff(sim, m, p.q, p.r, worldOut, p.level + socketDy(p.def, out), Math.max(1.4, speedHint));
    return;
  }
  beginLink(m, p, link, 0.38);
  m.speed = Math.max(1.55, speedHint);
  m.ignoreId = p.id;
  m.ignore = 0.15;
}

function finishRide(sim: Sim, m: Marble) {
  const ride = m.ride;
  if (!ride) return;
  if (ride.flip) m.gSign *= -1;
  if (ride.profile === "drop") {
    const end = sampleRide(ride, 1);
    m.mode = "flight";
    m.ride = null;
    m.pos = end;
    m.vel = { x: 0, y: -2.4 * m.gSign, z: 0 };
    m.ignoreId = ride.pieceId;
    m.ignore = 0.18;
    sim.events.push("drop");
    return;
  }
  const p = sim.byId.get(ride.pieceId);
  if (p?.def.behavior.kind === "start") {
    /* normal handoff */
  }
  handoff(sim, m, ride.q, ride.r, ride.to, ride.toLevel, m.speed);
}

function stepMarble(sim: Sim, m: Marble, dt: number) {
  if (m.mode === "gone") return;
  if (m.ignore > 0) m.ignore = Math.max(0, m.ignore - dt);

  if (m.mode === "wait") {
    const p = sim.byId.get(m.pieceId);
    if (!p) {
      lose(sim, m);
      return;
    }
    if (m.aux === 2) {
      const open = Math.sin(sim.time * 1.7) > -0.2;
      if (!open) return;
      const b = p.def.behavior;
      if (b.kind !== "gate") return;
      beginSynthetic(m, p, b.entry, b.exit, "flat", 0.2, 0.2);
      m.speed = Math.max(m.speed, 1.3);
      return;
    }
    m.wait -= dt;
    if (m.wait > 0) return;
    if (m.aux === 1) {
      const ang = m.auxPort * (Math.PI / 3);
      m.mode = "flight";
      m.hide = false;
      m.vel = { x: Math.cos(ang) * m.speed, y: m.ang, z: Math.sin(ang) * m.speed };
      m.ignore = 0.42;
      m.ignoreId = p.id;
      sim.events.push("launch");
      burst(sim, m.pos, m.color, 5);
      return;
    }
    if (m.aux === 3) {
      const b = p.def.behavior;
      if (b.kind !== "hold") return;
      m.hide = false;
      burst(sim, cellCenter(p.q, p.r, p.level), m.color, 6);
      beginSynthetic(m, p, b.entry, b.exit, "flat", 0.12, 0.5);
      m.speed = Math.max(m.speed, 2);
      return;
    }
    return;
  }

  if (m.mode === "swallowed") {
    m.wait -= dt;
    if (m.wait > 0) return;
    const p = sim.byId.get(m.pieceId);
    const c = p ? cellCenter(p.q, p.r, p.level) : m.pos;
    m.mode = "flight";
    m.hide = false;
    m.pos = { x: c.x, y: c.y + 0.2, z: c.z };
    m.vel = { x: (rng(sim) - 0.5) * 3.2, y: 6.8, z: (rng(sim) - 0.5) * 3.2 };
    m.ignore = 0.4;
    m.ignoreId = p?.id ?? "";
    sim.events.push("launch");
    return;
  }

  if (m.mode === "bowl") {
    const p = sim.byId.get(m.pieceId);
    if (!p) {
      lose(sim, m);
      return;
    }
    m.wait += dt;
    m.ang += dt * 4.2;
    const c = cellCenter(p.q, p.r, p.level);
    m.pos = {
      x: c.x + Math.cos(m.ang) * 0.22,
      y: c.y + 0.05,
      z: c.z + Math.sin(m.ang) * 0.22,
    };
    const mates = sim.marbles.filter((o) => o.mode === "bowl" && o.pieceId === p.id).length;
    if (m.wait > 2.15 || mates >= 3) {
      const b = p.def.behavior;
      const ports = b.kind === "mixer" ? b.ports : [0 as Port, 2 as Port, 4 as Port];
      const options = ports.filter((port) => port !== m.auxPort);
      const exit = options[Math.floor(rng(sim) * options.length)] ?? ports[0]!;
      const worldOut = mod(exit + p.rot, 6);
      handoff(sim, m, p.q, p.r, worldOut, p.level, 2.1);
    }
    return;
  }

  if (m.mode === "orbit") {
    const p = sim.byId.get(m.pieceId);
    if (!p) {
      lose(sim, m);
      return;
    }
    m.wait += dt;
    m.ang += dt * 3.4;
    const c = cellCenter(p.q, p.r, p.level);
    const rad = EDGE * 0.62;
    m.pos = { x: c.x + Math.cos(m.ang) * rad, y: c.y + 0.08, z: c.z + Math.sin(m.ang) * rad };
    if (m.wait >= m.aux) {
      const worldOut = mod(m.auxPort + p.rot, 6);
      handoff(sim, m, p.q, p.r, worldOut, p.level + socketDy(p.def, m.auxPort), Math.max(m.speed, 2.2));
    }
    return;
  }

  if (m.mode === "zip") {
    m.pos.x += m.vel.x * dt;
    m.pos.y += m.vel.y * dt;
    m.pos.z += m.vel.z * dt;
    m.wait += dt;
    const caught = zipCatch(sim, m);
    if (caught) return;
    if (m.wait > 1.6 || m.pos.y < -1.5) {
      m.mode = "flight";
      m.vel.y = -1.2 * m.gSign;
    }
    return;
  }

  if (m.mode === "rail" && m.ride) {
    if (!sim.byId.has(m.ride.pieceId)) {
      m.mode = "flight";
      m.vel = { x: 0, y: -1 * m.gSign, z: 0 };
      m.ride = null;
      return;
    }
    const ride = m.ride;
    if (ride.profile === "lift") m.speed = 1.25;
    if (ride.profile === "wave" && ride.friction > 2) m.speed = Math.min(m.speed, 0.72);
    const eps = 0.03;
    const aheadT = Math.min(1, m.t + eps);
    const here = sampleRide(ride, m.t);
    const ahead = sampleRide(ride, aheadT);
    const seg = Math.max(0.004, dist3(here, ahead));
    const dirY = (ahead.y - here.y) / seg;
    const slopeAcc = -GRAV * m.gSign * dirY;
    if (ride.profile !== "lift") {
      m.speed = Math.max(0, m.speed + (slopeAcc - ride.friction) * dt);
      m.speed = Math.min(m.speed, 14);
    }
    if (ride.profile === "loop" && m.t > 0.38 && m.t < 0.62 && m.speed < 1.2) {
      const tx = ahead.x - here.x;
      const ty = ahead.y - here.y;
      const tz = ahead.z - here.z;
      const l = Math.hypot(tx, ty, tz) || 1;
      m.mode = "flight";
      m.ride = null;
      m.pos = here;
      m.vel = { x: (tx / l) * m.speed, y: (ty / l) * m.speed, z: (tz / l) * m.speed };
      m.ignore = 0.2;
      m.ignoreId = ride.pieceId;
      sim.events.push("drop");
      return;
    }
    if (m.speed < 0.08 && dirY > 0.15) {
      m.aux += dt;
      if (m.aux > 0.9) {
        m.mode = "flight";
        m.ride = null;
        m.pos = here;
        m.vel = { x: 0, y: -0.4 * m.gSign, z: 0 };
        return;
      }
    } else m.aux = 0;
    const tAdv = (m.speed * dt) / (seg / eps);
    m.t += Math.min(0.16, tAdv);
    if (m.t >= 1) {
      m.t = 1;
      m.pos = sampleRide(ride, 1);
      finishRide(sim, m);
      return;
    }
    m.pos = sampleRide(ride, m.t);
    return;
  }

  if (m.mode === "flight") {
    m.vel.y -= GRAV * m.gSign * dt;
    m.vel.x *= 1 - 0.12 * dt;
    m.vel.z *= 1 - 0.12 * dt;
    m.pos.x += m.vel.x * dt;
    m.pos.y += m.vel.y * dt;
    m.pos.z += m.vel.z * dt;
    if (m.pos.y < -3.2 || m.pos.y > 22 || Math.hypot(m.pos.x, m.pos.z) > 28) {
      lose(sim, m);
      return;
    }
    considerCatch(sim, m);
  }
}

function zipCatch(sim: Sim, m: Marble): boolean {
  let best: Inst | null = null;
  let bestD = 0.62;
  for (const p of sim.pieces) {
    if (!p.def.zipPost && p.def.behavior.kind !== "goal" && !p.def.catchCenter) continue;
    if (p.id === m.ignoreId && m.ignore > 0) continue;
    const c = cellCenter(p.q, p.r, p.level);
    const d = Math.hypot(m.pos.x - c.x, m.pos.z - c.z);
    const dy = m.pos.y - c.y;
    if (d < bestD && dy < 1.1 && dy > -0.45) {
      best = p;
      bestD = d;
    }
  }
  if (!best) return false;
  const horiz = Math.hypot(m.vel.x, m.vel.z);
  catchToPiece(sim, m, best, Math.max(1.4, horiz * 0.45));
  return true;
}

function considerCatch(sim: Sim, m: Marble) {
  // Bumpers first.
  for (const p of sim.pieces) {
    if (!p.def.bumper) continue;
    if (m.ignore > 0 && m.ignoreId === p.id) continue;
    const c = cellCenter(p.q, p.r, p.level);
    const dx = m.pos.x - c.x;
    const dz = m.pos.z - c.z;
    const d = Math.hypot(dx, dz);
    if (d > 0.5 || d < 0.02) continue;
    const dy = Math.abs(m.pos.y - c.y);
    if (dy > 0.8) continue;
    const horiz = Math.hypot(m.vel.x, m.vel.z);
    if (horiz < 1.35 && p.def.links.length) {
      catchToPiece(sim, m, p, horiz);
      return;
    }
    const nx = dx / d;
    const nz = dz / d;
    const vn = m.vel.x * nx + m.vel.z * nz;
    if (vn < 0) {
      m.vel.x -= 2 * vn * nx;
      m.vel.z -= 2 * vn * nz;
      m.vel.x += nx * 1.2;
      m.vel.z += nz * 1.2;
      m.ignoreId = p.id;
      m.ignore = 0.28;
      sim.events.push("bump");
      return;
    }
  }

  let bestScore = 1e9;
  let best: { p: Inst; kind: "center" | "socket"; port: number } | null = null;

  for (const p of sim.pieces) {
    if (m.ignore > 0 && m.ignoreId === p.id) continue;
    if (p.def.catchCenter || p.def.behavior.kind === "goal" || p.def.behavior.kind === "fountain" || p.def.behavior.kind === "hole" || p.def.behavior.kind === "portal") {
      const c = cellCenter(p.q, p.r, p.level);
      const dx = m.pos.x - c.x;
      const dz = m.pos.z - c.z;
      const dy = m.pos.y - c.y;
      const d = Math.hypot(dx, dz);
      if (d < p.def.catchRadius && dy < p.def.catchHeight && dy > -0.35) {
        const score = d + Math.abs(dy) * 0.25;
        if (score < bestScore) {
          bestScore = score;
          best = { p, kind: "center", port: 0 };
        }
      }
    }
    for (const sock of p.def.sockets) {
      const world = mod(sock.port + p.rot, 6);
      const level = p.level + sock.dy;
      if (!accepts(p, world, level)) continue;
      const s = socketPos(p.q, p.r, level, world);
      const dx = m.pos.x - s.x;
      const dz = m.pos.z - s.z;
      const dy = m.pos.y - s.y;
      const d = Math.hypot(dx, dz);
      if (d < 0.34 && dy < 0.48 && dy > -0.22) {
        if (m.vel.y * m.gSign > 2.2 && dy > 0.08) continue;
        const score = d + Math.abs(dy) * 0.2;
        if (score < bestScore) {
          bestScore = score;
          best = { p, kind: "socket", port: world };
        }
      }
    }
  }

  if (!best) return;
  const horiz = Math.hypot(m.vel.x, m.vel.z);
  if (best.kind === "center") {
    // Fix portal/hole/mixer: enterPiece expects a world port. Compute one that maps to a valid local.
    const p = best.p;
    const b = p.def.behavior;
    if (b.kind === "portal" || b.kind === "hole" || b.kind === "goal" || b.kind === "fountain") {
      m.pos = cellCenter(p.q, p.r, p.level);
      enterPiece(sim, m, p, mod(3 + p.rot, 6), Math.max(1.2, horiz));
      return;
    }
    if (b.kind === "mixer") {
      enterPiece(sim, m, p, mod(b.ports[0]! + p.rot, 6), horiz);
      return;
    }
    catchToPiece(sim, m, p, Math.max(1.3, horiz * 0.55 + Math.abs(m.vel.y) * 0.22));
    return;
  }
  enterPiece(sim, m, best.p, best.port, Math.max(1.1, horiz * 0.75));
}

function spawnStarts(sim: Sim, dt: number) {
  if (!sim.playing) return;
  for (const p of sim.pieces) {
    const b = p.def.behavior;
    if (b.kind !== "start") continue;
    const rt = rtOf(p);
    if (rt.spawned >= b.stock) continue;
    rt.cool -= dt;
    if (rt.cool > 0) continue;
    rt.cool = b.interval;
    rt.spawned += 1;
    const link = p.def.links[0];
    if (!link) continue;
    const m = makeMarble(sim, cellCenter(p.q, p.r, p.level));
    m.gSign = 1;
    beginLink(m, p, link, 0.04);
    m.speed = Math.max(m.speed, 3.1);
    sim.marbles.push(m);
    sim.events.push("spawn");
  }
}

export function stepSim(sim: Sim, dt: number) {
  sim.events.length = 0;
  if (!sim.playing) {
    ageFx(sim, dt);
    return;
  }
  sim.time += dt;
  spawnStarts(sim, dt);
  // iterate snapshot length so spawns this frame wait
  const n = sim.marbles.length;
  for (let i = 0; i < n; i++) {
    const m = sim.marbles[i]!;
    if (m.fresh) {
      m.fresh = false;
      continue;
    }
    stepMarble(sim, m, dt);
  }
  // marbles created mid-step with fresh=true are skipped once; clear fresh on those added after n? 
  // begin during step sets fresh true, loop only goes to original n, so new ones aren't stepped. Clear fresh so next frame runs.
  for (let i = n; i < sim.marbles.length; i++) sim.marbles[i]!.fresh = false;
  ageFx(sim, dt);
  if (sim.fx.length > 48) sim.fx.splice(0, sim.fx.length - 48);
  if (sim.marbles.length > 24) {
    sim.marbles = sim.marbles.filter((m) => m.mode !== "gone");
  }
}

function ageFx(sim: Sim, dt: number) {
  for (const f of sim.fx) {
    f.life -= dt;
    f.x += f.vx * dt;
    f.y += f.vy * dt;
    f.z += f.vz * dt;
    f.vy -= GRAV * 0.35 * dt;
  }
  if (sim.fx.some((f) => f.life <= 0)) sim.fx = sim.fx.filter((f) => f.life > 0);
}

export function activeMarbles(sim: Sim): number {
  let n = 0;
  for (const m of sim.marbles) if (m.mode !== "gone") n++;
  return n;
}

export function startsDone(sim: Sim): boolean {
  for (const p of sim.pieces) {
    const b = p.def.behavior;
    if (b.kind === "start" && rtOf(p).spawned < b.stock) return false;
  }
  return true;
}

/** Rails to draw: one tube per undirected connection. */
export function visualRides(p: Placed, def: Def): Ride[] {
  const seen = new Set<string>();
  const rides: Ride[] = [];
  for (const link of def.links) {
    const a = link.from;
    const b = link.to;
    const key = `${link.profile}:${Math.min(a, b)}:${Math.max(a, b)}:${link.fromDy}:${link.toDy}`;
    if (seen.has(key)) continue;
    seen.add(key);
    rides.push({
      pieceId: p.id,
      q: p.q,
      r: p.r,
      from: mod(link.from + p.rot, 6) as Port,
      to: mod(link.to + p.rot, 6) as Port,
      fromLevel: p.level + link.fromDy,
      toLevel: p.level + link.toDy,
      profile: link.profile,
      friction: link.friction,
      kick: link.kick,
      trail: link.trail,
      flip: false,
    });
  }
  return rides;
}
