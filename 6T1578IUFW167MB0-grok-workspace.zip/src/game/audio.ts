let ctx: AudioContext | null = null;

export function unlockAudio() {
  if (typeof window === "undefined") return;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
  }
  if (ctx.state === "suspended") void ctx.resume();
}

function tone(freq: number, dur: number, gain: number, type: OscillatorType = "sine", delay = 0) {
  if (!ctx) return;
  const t0 = ctx.currentTime + delay;
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(gain, t0 + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(g);
  g.connect(ctx.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}

export function playCue(kind: string) {
  if (!ctx) return;
  if (kind === "goal") {
    tone(523, 0.18, 0.05);
    tone(784, 0.28, 0.04, "sine", 0.06);
    return;
  }
  if (kind === "launch") tone(196, 0.12, 0.045, "triangle");
  else if (kind === "drop") tone(146, 0.1, 0.04, "sine");
  else if (kind === "portal") tone(880, 0.16, 0.035, "sine");
  else if (kind === "spawn") tone(494, 0.07, 0.025, "sine");
}
