import { create } from "zustand";
import { CATALOG } from "./catalog";
import { GRID_LIMIT } from "./hex";
import { buildDream, buildMuseum, nextPortalChannel } from "./layouts";
import type { Placed } from "./sim";

const KEY = "ecliptique-v1";

function cubeOk(q: number, r: number): boolean {
  return Math.max(Math.abs(q), Math.abs(r), Math.abs(-q - r)) <= GRID_LIMIT;
}

function loadPieces(): Placed[] {
  if (typeof window === "undefined") return buildDream();
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return buildDream();
    const data = JSON.parse(raw) as { pieces?: Placed[] };
    if (!Array.isArray(data.pieces)) return buildDream();
    const pieces = data.pieces.filter(
      (p) => p && typeof p.id === "string" && CATALOG[p.type] && cubeOk(p.q, p.r),
    );
    return pieces.length ? pieces : buildDream();
  } catch {
    return buildDream();
  }
}

function persist(pieces: Placed[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify({ v: 1, pieces }));
  } catch {
    /* ignore quota */
  }
}

function uid(): string {
  return `p${Math.random().toString(36).slice(2, 9)}`;
}

type Hud = { score: number; arrived: number; lost: number; active: number };

type EditorState = {
  pieces: Placed[];
  rev: number;
  selectedId: string | null;
  tool: string;
  brushRot: number;
  brushLevel: number;
  mode: "place" | "erase";
  playing: boolean;
  runToken: number;
  score: number;
  arrived: number;
  lost: number;
  active: number;
  hover: { q: number; r: number } | null;
  undo: Placed[][];
  viewToken: number;
  cat: string;
  muted: boolean;
  confirmClear: boolean;
  setHover: (h: { q: number; r: number } | null) => void;
  setTool: (id: string) => void;
  setCat: (id: string) => void;
  setMode: (m: "place" | "erase") => void;
  rotateBrush: (dir: number) => void;
  setBrushLevel: (level: number) => void;
  placeAt: (q: number, r: number) => void;
  select: (id: string | null) => void;
  rotateSelected: (dir?: number) => void;
  nudgeLevel: (d: number) => void;
  removeSelected: () => void;
  setChannel: (channel: number) => void;
  undoOnce: () => void;
  loadDream: () => void;
  loadMuseum: () => void;
  clearAll: () => void;
  togglePlay: () => void;
  replay: () => void;
  setHud: (h: Hud) => void;
  toggleMute: () => void;
  armClear: () => void;
};

function withUndo(pieces: Placed[], undo: Placed[][]): Placed[][] {
  const next = [...undo, pieces.map((p) => ({ ...p }))];
  return next.length > 40 ? next.slice(next.length - 40) : next;
}

export const useEditor = create<EditorState>((set, get) => ({
  pieces: loadPieces(),
  rev: 1,
  selectedId: null,
  tool: "courbe",
  brushRot: 0,
  brushLevel: 2,
  mode: "place",
  playing: false,
  runToken: 0,
  score: 0,
  arrived: 0,
  lost: 0,
  active: 0,
  hover: null,
  undo: [],
  viewToken: 0,
  cat: "voies",
  muted: false,
  confirmClear: false,

  setHover: (hover) => set({ hover }),
  setTool: (tool) => set({ tool, mode: "place" }),
  setCat: (cat) => set({ cat }),
  setMode: (mode) => set({ mode }),
  rotateBrush: (dir) =>
    set((s) => {
      if (s.selectedId) {
        const pieces = s.pieces.map((p) =>
          p.id === s.selectedId ? { ...p, rot: (p.rot + dir + 6) % 6 } : p,
        );
        persist(pieces);
        return { pieces, rev: s.rev + 1, brushRot: (s.brushRot + dir + 6) % 6 };
      }
      return { brushRot: (s.brushRot + dir + 6) % 6 };
    }),
  setBrushLevel: (level) => set({ brushLevel: Math.max(0, Math.min(5, level)) }),

  placeAt: (q, r) => {
    const s = get();
    if (!cubeOk(q, r)) return;
    if (s.mode === "erase") {
      const target =
        s.pieces.find((p) => p.q === q && p.r === r && p.level === s.brushLevel) ??
        [...s.pieces].reverse().find((p) => p.q === q && p.r === r);
      if (!target) return;
      const pieces = s.pieces.filter((p) => p.id !== target.id);
      persist(pieces);
      set({
        pieces,
        rev: s.rev + 1,
        undo: withUndo(s.pieces, s.undo),
        selectedId: s.selectedId === target.id ? null : s.selectedId,
      });
      return;
    }
    const hit = s.pieces.find((p) => p.q === q && p.r === r && p.level === s.brushLevel);
    if (hit) {
      set({ selectedId: hit.id, brushRot: hit.rot });
      return;
    }
    if (!CATALOG[s.tool]) return;
    const piece: Placed = {
      id: uid(),
      type: s.tool,
      q,
      r,
      level: s.brushLevel,
      rot: s.brushRot,
    };
    if (s.tool === "portail") piece.channel = nextPortalChannel(s.pieces);
    const pieces = [...s.pieces, piece];
    persist(pieces);
    set({
      pieces,
      rev: s.rev + 1,
      undo: withUndo(s.pieces, s.undo),
      selectedId: piece.id,
    });
  },

  select: (selectedId) => set({ selectedId }),

  rotateSelected: (dir = 1) => get().rotateBrush(dir),

  nudgeLevel: (d) =>
    set((s) => {
      if (!s.selectedId) {
        const brushLevel = Math.max(0, Math.min(5, s.brushLevel + d));
        return { brushLevel };
      }
      const pieces = s.pieces.map((p) => {
        if (p.id !== s.selectedId) return p;
        const level = Math.max(0, Math.min(5, p.level + d));
        const blocked = s.pieces.some((o) => o.id !== p.id && o.q === p.q && o.r === p.r && o.level === level);
        return blocked ? p : { ...p, level };
      });
      persist(pieces);
      const moved = pieces.find((p) => p.id === s.selectedId);
      return { pieces, rev: s.rev + 1, brushLevel: moved?.level ?? s.brushLevel };
    }),

  removeSelected: () => {
    const s = get();
    if (!s.selectedId) return;
    const pieces = s.pieces.filter((p) => p.id !== s.selectedId);
    persist(pieces);
    set({ pieces, rev: s.rev + 1, undo: withUndo(s.pieces, s.undo), selectedId: null });
  },

  setChannel: (channel) => {
    const s = get();
    if (!s.selectedId) return;
    const pieces = s.pieces.map((p) => (p.id === s.selectedId ? { ...p, channel } : p));
    persist(pieces);
    set({ pieces, rev: s.rev + 1 });
  },

  undoOnce: () => {
    const s = get();
    const prev = s.undo[s.undo.length - 1];
    if (!prev) return;
    persist(prev);
    set({ pieces: prev, undo: s.undo.slice(0, -1), rev: s.rev + 1, selectedId: null });
  },

  loadDream: () => {
    const pieces = buildDream();
    persist(pieces);
    set((s) => ({
      pieces,
      rev: s.rev + 1,
      undo: withUndo(s.pieces, s.undo),
      selectedId: null,
      playing: false,
      viewToken: s.viewToken + 1,
      runToken: s.runToken + 1,
      confirmClear: false,
    }));
  },

  loadMuseum: () => {
    const pieces = buildMuseum();
    persist(pieces);
    set((s) => ({
      pieces,
      rev: s.rev + 1,
      undo: withUndo(s.pieces, s.undo),
      selectedId: null,
      playing: false,
      viewToken: s.viewToken + 1,
      runToken: s.runToken + 1,
      confirmClear: false,
    }));
  },

  clearAll: () => {
    persist([]);
    set((s) => ({
      pieces: [],
      rev: s.rev + 1,
      undo: withUndo(s.pieces, s.undo),
      selectedId: null,
      playing: false,
      confirmClear: false,
      runToken: s.runToken + 1,
    }));
  },

  togglePlay: () => set((s) => ({ playing: !s.playing })),
  replay: () => set((s) => ({ playing: true, runToken: s.runToken + 1 })),
  setHud: (h) => set(h),
  toggleMute: () => set((s) => ({ muted: !s.muted })),
  armClear: () => set((s) => ({ confirmClear: !s.confirmClear })),
}));
