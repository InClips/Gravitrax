import type { Port } from "./hex";

export type CategoryId = "voies" | "noeuds" | "chutes" | "elan" | "fins" | "songe";

export type Profile =
  | "flat"
  | "wave"
  | "hump"
  | "dip"
  | "loop"
  | "spiral"
  | "lift"
  | "drop"
  | "tunnel";

export type Behavior =
  | { kind: "rails" }
  | { kind: "start"; stock: number; interval: number }
  | { kind: "goal" }
  | { kind: "fountain" }
  | { kind: "launcher"; entry: Port; heading: Port; power: number; lift: number; delay: number }
  | { kind: "drop"; depth: number }
  | { kind: "zip"; entry: Port; heading: Port }
  | { kind: "switch"; entry: Port; exits: Port[] }
  | { kind: "random"; entry: Port; exits: Port[] }
  | { kind: "timed"; entry: Port; exits: Port[]; period: number }
  | { kind: "gate"; entry: Port; exit: Port }
  | { kind: "portal" }
  | { kind: "split"; entry: Port; exits: Port[] }
  | { kind: "clone"; entry: Port; exits: Port[] }
  | { kind: "hold"; entry: Port; exit: Port; delay: number }
  | { kind: "mixer"; ports: Port[] }
  | { kind: "hole" }
  | { kind: "orbit"; entry: Port; exit: Port; time: number }
  | { kind: "bumper" };

export type Link = {
  from: Port;
  to: Port;
  profile: Profile;
  fromDy: number;
  toDy: number;
  friction: number;
  kick: number;
  trail: boolean;
};

export type Socket = { port: Port; dy: number };

export type Def = {
  id: string;
  name: string;
  blurb: string;
  cat: CategoryId;
  links: Link[];
  sockets: Socket[];
  behavior: Behavior;
  catchCenter: boolean;
  catchRadius: number;
  catchHeight: number;
  outLocal: Port;
  zipPost: boolean;
  bumper: boolean;
  flipOnExit: boolean;
  trail: boolean;
  accent: "gold" | "teal" | "coral";
};

type RawLink = {
  from: Port;
  to: Port;
  profile?: Profile;
  fromDy?: number;
  toDy?: number;
  friction?: number;
  kick?: number;
  trail?: boolean;
  oneWay?: boolean;
  kickBoth?: boolean;
};

type Raw = {
  id: string;
  name: string;
  blurb: string;
  cat: CategoryId;
  links?: RawLink[];
  behavior?: Behavior;
  sockets?: Socket[];
  catchCenter?: boolean;
  catchRadius?: number;
  catchHeight?: number;
  outLocal?: Port;
  zipPost?: boolean;
  bumper?: boolean;
  flipOnExit?: boolean;
  trail?: boolean;
  accent?: Def["accent"];
  allSockets?: boolean;
};

export const CATEGORIES: Array<{ id: CategoryId; label: string }> = [
  { id: "voies", label: "Voies" },
  { id: "noeuds", label: "Nœuds" },
  { id: "chutes", label: "Chutes" },
  { id: "elan", label: "Élan" },
  { id: "fins", label: "Fins" },
  { id: "songe", label: "Songe" },
];

function bi(
  from: Port,
  to: Port,
  o: Omit<RawLink, "from" | "to"> = {},
): RawLink[] {
  const forward: RawLink = { from, to, ...o };
  if (o.oneWay) return [forward];
  return [
    forward,
    {
      from: to,
      to: from,
      profile: o.profile,
      fromDy: o.toDy ?? 0,
      toDy: o.fromDy ?? 0,
      friction: o.friction,
      kick: o.kickBoth ? o.kick : 0,
      trail: o.trail,
      oneWay: true,
    },
  ];
}

function compile(raw: Raw): Def {
  const links: Link[] = [];
  for (const l of raw.links ?? []) {
    links.push({
      from: l.from,
      to: l.to,
      profile: l.profile ?? "flat",
      fromDy: l.fromDy ?? 0,
      toDy: l.toDy ?? 0,
      friction: l.friction ?? 0.28,
      kick: l.kick ?? 0,
      trail: Boolean(l.trail || raw.trail),
    });
  }
  const sock = new Map<number, number>();
  for (const s of raw.sockets ?? []) sock.set(s.port, s.dy);
  for (const l of links) {
    const a = sock.get(l.from);
    if (a === undefined) sock.set(l.from, l.fromDy);
    const b = sock.get(l.to);
    if (b === undefined) sock.set(l.to, l.toDy);
  }
  if (raw.allSockets) {
    for (let p = 0; p < 6; p++) if (!sock.has(p)) sock.set(p, 0);
  }
  const behavior = raw.behavior ?? { kind: "rails" };
  return {
    id: raw.id,
    name: raw.name,
    blurb: raw.blurb,
    cat: raw.cat,
    links,
    sockets: [...sock.entries()].map(([port, dy]) => ({ port: port as Port, dy })),
    behavior,
    catchCenter: Boolean(raw.catchCenter),
    catchRadius: raw.catchRadius ?? (raw.catchCenter ? 0.46 : 0.3),
    catchHeight: raw.catchHeight ?? 0.7,
    outLocal: raw.outLocal ?? 0,
    zipPost: Boolean(raw.zipPost),
    bumper: Boolean(raw.bumper),
    flipOnExit: Boolean(raw.flipOnExit),
    trail: Boolean(raw.trail),
    accent: raw.accent ?? (raw.cat === "songe" ? "teal" : "gold"),
  };
}

const P = (n: number) => n as Port;

const RAW: Raw[] = [
  // —— Voies ——
  {
    id: "droit",
    name: "Ligne",
    blurb: "Rail droit entre deux faces opposées.",
    cat: "voies",
    links: bi(P(3), P(0)),
  },
  {
    id: "courbe",
    name: "Courbe",
    blurb: "Virage doux, soixante degrés.",
    cat: "voies",
    links: bi(P(0), P(2), { friction: 0.2 }),
  },
  {
    id: "virage",
    name: "Épingle",
    blurb: "Virage serré, cent vingt degrés.",
    cat: "voies",
    links: bi(P(0), P(1), { friction: 0.22 }),
  },
  {
    id: "serpent",
    name: "Serpentin",
    blurb: "Ondulation qui berce la bille.",
    cat: "voies",
    links: bi(P(3), P(0), { profile: "wave", friction: 0.34 }),
  },
  {
    id: "rampe",
    name: "Rampe",
    blurb: "Monte d'un étage vers la face avant.",
    cat: "voies",
    links: bi(P(3), P(0), { profile: "flat", fromDy: 0, toDy: 1, friction: 0.2 }),
  },
  {
    id: "descente",
    name: "Pente",
    blurb: "Descend d'un étage et prend de la vitesse.",
    cat: "voies",
    links: bi(P(3), P(0), { fromDy: 0, toDy: -1, friction: 0.12 }),
  },
  {
    id: "frein",
    name: "Velours",
    blurb: "Freine fort, presque jusqu'à l'arrêt.",
    cat: "voies",
    links: bi(P(3), P(0), { friction: 5.2, kickBoth: true }),
  },
  {
    id: "souffle",
    name: "Souffle",
    blurb: "Un coup d'élan le long du rail.",
    cat: "voies",
    links: bi(P(3), P(0), { kick: 3.4, kickBoth: true, friction: 0.1 }),
    accent: "teal",
  },
  {
    id: "pont",
    name: "Arche",
    blurb: "Pont bombé. Le vide passe dessous.",
    cat: "voies",
    links: bi(P(3), P(0), { profile: "hump", friction: 0.2 }),
  },
  {
    id: "tunnel",
    name: "Tunnel",
    blurb: "Galerie close, la bille file à l'abri.",
    cat: "voies",
    links: bi(P(3), P(0), { profile: "tunnel", friction: 0.16 }),
  },
  {
    id: "tube",
    name: "Siphon",
    blurb: "Tube souple qui plonge puis remonte.",
    cat: "voies",
    links: bi(P(3), P(0), { profile: "dip", friction: 0.18 }),
  },
  {
    id: "pilier",
    name: "Pilier",
    blurb: "Ligne posée sur un fût de verre.",
    cat: "voies",
    links: bi(P(3), P(0)),
  },
  // —— Nœuds ——
  {
    id: "croix",
    name: "Croisement",
    blurb: "Deux lignes se croisent sans se parler.",
    cat: "noeuds",
    links: [...bi(P(0), P(3)), ...bi(P(1), P(4))],
  },
  {
    id: "jonction",
    name: "Jonction",
    blurb: "Les côtés rejoignent l'axe principal.",
    cat: "noeuds",
    links: [
      ...bi(P(0), P(3)),
      { from: P(1), to: P(3), oneWay: true },
      { from: P(5), to: P(3), oneWay: true },
    ],
  },
  {
    id: "etoile",
    name: "Étoile",
    blurb: "Six faces, trois axes qui se traversent.",
    cat: "noeuds",
    links: [...bi(P(0), P(3)), ...bi(P(1), P(4)), ...bi(P(2), P(5))],
  },
  {
    id: "aiguillage",
    name: "Aiguillage",
    blurb: "Bascule à chaque bille entre deux sorties.",
    cat: "noeuds",
    behavior: { kind: "switch", entry: P(3), exits: [P(2), P(4)] },
    sockets: [
      { port: P(3), dy: 0 },
      { port: P(2), dy: 0 },
      { port: P(4), dy: 0 },
    ],
  },
  {
    id: "hasard",
    name: "Hasard",
    blurb: "Choisit une sortie au petit bonheur.",
    cat: "noeuds",
    behavior: { kind: "random", entry: P(3), exits: [P(0), P(2), P(4)] },
    sockets: [
      { port: P(3), dy: 0 },
      { port: P(0), dy: 0 },
      { port: P(2), dy: 0 },
      { port: P(4), dy: 0 },
    ],
  },
  {
    id: "fusion",
    name: "Confluent",
    blurb: "Trois arrivées, une seule bouche.",
    cat: "noeuds",
    links: [
      { from: P(1), to: P(0), oneWay: true },
      { from: P(5), to: P(0), oneWay: true },
      { from: P(3), to: P(0), oneWay: true },
    ],
  },
  {
    id: "bascule",
    name: "Bascule",
    blurb: "Planche qui penche et change de côté.",
    cat: "noeuds",
    behavior: { kind: "switch", entry: P(3), exits: [P(1), P(5)] },
    sockets: [
      { port: P(3), dy: 0 },
      { port: P(1), dy: 0 },
      { port: P(5), dy: 0 },
    ],
  },
  {
    id: "vanne",
    name: "Vanne",
    blurb: "S'ouvre et se ferme avec le temps.",
    cat: "noeuds",
    behavior: { kind: "gate", entry: P(3), exit: P(0) },
    sockets: [
      { port: P(3), dy: 0 },
      { port: P(0), dy: 0 },
    ],
  },
  {
    id: "melangeur",
    name: "Mélangeur",
    blurb: "Tourbillon : les billes dansent puis sortent.",
    cat: "noeuds",
    behavior: { kind: "mixer", ports: [P(0), P(2), P(4)] },
    allSockets: false,
    sockets: [
      { port: P(0), dy: 0 },
      { port: P(2), dy: 0 },
      { port: P(4), dy: 0 },
    ],
    catchCenter: true,
    catchRadius: 0.4,
  },
  // —— Chutes ——
  {
    id: "chute",
    name: "Puits",
    blurb: "Tombe d'un étage au centre de la dalle.",
    cat: "chutes",
    behavior: { kind: "drop", depth: 1 },
    allSockets: true,
  },
  {
    id: "chute2",
    name: "Gouffre",
    blurb: "Chute libre de deux étages.",
    cat: "chutes",
    behavior: { kind: "drop", depth: 2 },
    allSockets: true,
  },
  {
    id: "receptacle",
    name: "Corbeille",
    blurb: "Reçoit une chute et relance sur la face avant.",
    cat: "chutes",
    links: [{ from: P(3), to: P(0), oneWay: true, kick: 0.4 }],
    catchCenter: true,
    catchRadius: 0.5,
    catchHeight: 1.15,
    outLocal: P(0),
  },
  {
    id: "entonnoir",
    name: "Entonnoir",
    blurb: "Large bouche pour les billes en vol.",
    cat: "chutes",
    links: [{ from: P(3), to: P(0), oneWay: true, kick: 0.6 }],
    catchCenter: true,
    catchRadius: 0.72,
    catchHeight: 1.6,
    outLocal: P(0),
  },
  {
    id: "spirale",
    name: "Spirale",
    blurb: "Hélice qui descend de deux étages.",
    cat: "chutes",
    links: bi(P(0), P(3), { profile: "spiral", fromDy: 0, toDy: -2, friction: 0.08, kick: 1.2 }),
  },
  {
    id: "looping",
    name: "Looping",
    blurb: "Boucle verticale. Trop lent : on décroche.",
    cat: "chutes",
    links: bi(P(3), P(0), { profile: "loop", friction: 0.08 }),
  },
  {
    id: "balcon",
    name: "Balcon",
    blurb: "Pousse la bille dans le vide, tout droit.",
    cat: "chutes",
    behavior: { kind: "launcher", entry: P(3), heading: P(0), power: 2.4, lift: 0.35, delay: 0.08 },
    sockets: [{ port: P(3), dy: 0 }],
  },
  // —— Élan ——
  {
    id: "depart",
    name: "Source",
    blurb: "Libère une file de billes-étoiles.",
    cat: "elan",
    behavior: { kind: "start", stock: 5, interval: 0.82 },
    links: [{ from: P(3), to: P(0), oneWay: true, kick: 2.6, friction: 0.05 }],
    accent: "gold",
  },
  {
    id: "catapulte",
    name: "Catapulte",
    blurb: "Bras qui lobbe la bille en cloche.",
    cat: "elan",
    behavior: { kind: "launcher", entry: P(3), heading: P(0), power: 4.6, lift: 6.4, delay: 0.22 },
    sockets: [{ port: P(3), dy: 0 }],
  },
  {
    id: "canon",
    name: "Canon",
    blurb: "Tir tendu vers la face avant.",
    cat: "elan",
    behavior: { kind: "launcher", entry: P(3), heading: P(0), power: 8.2, lift: 3.1, delay: 0.16 },
    sockets: [{ port: P(3), dy: 0 }],
  },
  {
    id: "aimant",
    name: "Aimant",
    blurb: "Canon magnétique, très rapide, très plat.",
    cat: "elan",
    behavior: { kind: "launcher", entry: P(3), heading: P(0), power: 13.5, lift: 1.35, delay: 0.2 },
    sockets: [{ port: P(3), dy: 0 }],
  },
  {
    id: "volcan",
    name: "Volcan",
    blurb: "Jaillit vers le haut puis retombe plus loin.",
    cat: "elan",
    behavior: { kind: "launcher", entry: P(3), heading: P(0), power: 3.4, lift: 8.2, delay: 0.18 },
    sockets: [{ port: P(3), dy: 0 }],
  },
  {
    id: "trampoline",
    name: "Trampoline",
    blurb: "Rebond haut, un peu vers l'avant.",
    cat: "elan",
    behavior: { kind: "launcher", entry: P(3), heading: P(0), power: 2.4, lift: 9, delay: 0.12 },
    sockets: [{ port: P(3), dy: 0 }],
    catchCenter: true,
    catchRadius: 0.42,
  },
  {
    id: "marteau",
    name: "Marteau",
    blurb: "Frappe la bille de côté.",
    cat: "elan",
    behavior: { kind: "launcher", entry: P(3), heading: P(1), power: 6.4, lift: 2.4, delay: 0.28 },
    sockets: [{ port: P(3), dy: 0 }],
  },
  {
    id: "tremplin",
    name: "Saut",
    blurb: "Petit bond par-dessus un vide.",
    cat: "elan",
    behavior: { kind: "launcher", entry: P(3), heading: P(0), power: 6.2, lift: 3.3, delay: 0.1 },
    sockets: [{ port: P(3), dy: 0 }],
  },
  {
    id: "elevateur",
    name: "Élévateur",
    blurb: "Monte de deux étages, sans se presser.",
    cat: "elan",
    links: bi(P(3), P(0), { profile: "lift", fromDy: 0, toDy: 2, friction: 0, oneWay: true }),
  },
  {
    id: "tyrolienne",
    name: "Fil",
    blurb: "Glisse tout droit jusqu'à une butée.",
    cat: "elan",
    behavior: { kind: "zip", entry: P(3), heading: P(0) },
    sockets: [{ port: P(3), dy: 0 }],
  },
  {
    id: "butee",
    name: "Butée",
    blurb: "Arrête un fil, renvoie les billes trop vives.",
    cat: "elan",
    links: [{ from: P(3), to: P(0), oneWay: true, kick: 0.8 }],
    zipPost: true,
    bumper: true,
    catchCenter: true,
    catchRadius: 0.55,
    catchHeight: 1.2,
  },
  // —— Fins ——
  {
    id: "arrivee",
    name: "Seuil",
    blurb: "La bille s'endort. Un point.",
    cat: "fins",
    behavior: { kind: "goal" },
    allSockets: true,
    catchCenter: true,
    catchRadius: 0.48,
    catchHeight: 1,
  },
  {
    id: "carillon",
    name: "Carillon",
    blurb: "Arrivée qui sonne dans le vide.",
    cat: "fins",
    behavior: { kind: "goal" },
    allSockets: true,
    catchCenter: true,
    catchRadius: 0.5,
    catchHeight: 1.1,
    accent: "gold",
  },
  {
    id: "panier",
    name: "Panier",
    blurb: "Cueille les billes qui retombent du ciel.",
    cat: "fins",
    behavior: { kind: "goal" },
    allSockets: true,
    catchCenter: true,
    catchRadius: 0.78,
    catchHeight: 1.8,
  },
  {
    id: "fontaine",
    name: "Fontaine",
    blurb: "Compte la bille, parfois en rend une au ciel.",
    cat: "fins",
    behavior: { kind: "fountain" },
    allSockets: true,
    catchCenter: true,
    catchRadius: 0.5,
    accent: "teal",
  },
  // —— Songe ——
  {
    id: "vortex",
    name: "Vortex",
    blurb: "Le temps s'épaissit. La bille rampe.",
    cat: "songe",
    links: bi(P(3), P(0), { friction: 3.4, profile: "wave" }),
    accent: "teal",
  },
  {
    id: "portail",
    name: "Trou de ver",
    blurb: "Relie le jumeau de même teinte.",
    cat: "songe",
    behavior: { kind: "portal" },
    allSockets: true,
    catchCenter: true,
    accent: "teal",
  },
  {
    id: "miroir",
    name: "Miroir",
    blurb: "Dédouble la bille en deux trajectoires.",
    cat: "songe",
    behavior: { kind: "clone", entry: P(3), exits: [P(0), P(1)] },
    sockets: [
      { port: P(3), dy: 0 },
      { port: P(0), dy: 0 },
      { port: P(1), dy: 0 },
    ],
    accent: "coral",
  },
  {
    id: "inversion",
    name: "Inversion",
    blurb: "Après ce rail, la bille tombe vers le haut.",
    cat: "songe",
    links: bi(P(3), P(0)),
    flipOnExit: true,
    accent: "coral",
  },
  {
    id: "nebuleuse",
    name: "Nébuleuse",
    blurb: "Accélère et laisse une couronne.",
    cat: "songe",
    links: bi(P(3), P(0), { kick: 2.4, kickBoth: true, friction: 0.08, trail: true }),
    trail: true,
    accent: "teal",
  },
  {
    id: "eclipse",
    name: "Éclipse",
    blurb: "La bille disparaît, puis reparaît devant.",
    cat: "songe",
    behavior: { kind: "hold", entry: P(3), exit: P(0), delay: 0.9 },
    sockets: [
      { port: P(3), dy: 0 },
      { port: P(0), dy: 0 },
    ],
  },
  {
    id: "constellation",
    name: "Constellation",
    blurb: "Courbe légère, presque sans frottement.",
    cat: "songe",
    links: bi(P(0), P(2), { friction: 0.05, trail: true }),
    trail: true,
    accent: "gold",
  },
  {
    id: "pendule",
    name: "Pendule",
    blurb: "La sortie oscille entre gauche et droite.",
    cat: "songe",
    behavior: { kind: "timed", entry: P(3), exits: [P(1), P(5)], period: 1.4 },
    sockets: [
      { port: P(3), dy: 0 },
      { port: P(1), dy: 0 },
      { port: P(5), dy: 0 },
    ],
  },
  {
    id: "prisme",
    name: "Prisme",
    blurb: "Une bille entre, trois étoiles sortent.",
    cat: "songe",
    behavior: { kind: "split", entry: P(3), exits: [P(0), P(2), P(4)] },
    sockets: [
      { port: P(3), dy: 0 },
      { port: P(0), dy: 0 },
      { port: P(2), dy: 0 },
      { port: P(4), dy: 0 },
    ],
    accent: "coral",
  },
  {
    id: "trou",
    name: "Singularité",
    blurb: "Avale, puis recrache vers le ciel.",
    cat: "songe",
    behavior: { kind: "hole" },
    allSockets: true,
    catchCenter: true,
    catchRadius: 0.5,
    accent: "coral",
  },
  {
    id: "lune",
    name: "Lune",
    blurb: "Orbite paresseuse, puis s'échappe devant.",
    cat: "songe",
    behavior: { kind: "orbit", entry: P(3), exit: P(0), time: 1.35 },
    sockets: [
      { port: P(3), dy: 0 },
      { port: P(0), dy: 0 },
    ],
    catchCenter: true,
  },
];

export const PIECES: Def[] = RAW.map(compile);
export const CATALOG: Record<string, Def> = Object.fromEntries(PIECES.map((d) => [d.id, d]));

export const MARBLE_COLORS = ["#f4efe6", "#e7b15a", "#3ecfb8", "#e25b6a", "#9eb7e8", "#f0b3c8"];

export const CHANNEL_COLORS = ["#e7b15a", "#3ecfb8", "#e25b6a", "#9eb7e8", "#f4efe6", "#f0b3c8"];

export function socketDy(def: Def, local: number): number {
  return def.sockets.find((s) => s.port === local)?.dy ?? 0;
}
